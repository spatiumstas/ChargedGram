import Cocoa
import TGUIKit

final class CandidatePanelHost {
    let rowView = View(frame: CGRect(x: 0, y: 0, width: 180, height: 130))
    let bubbleView = MaskBubbleView(frame: .zero)
    var cutBandViews: [NSView] = []
    init() { rowView.addSubview(bubbleView) }
    func cutBands(_ item: ChatRowItem) -> [CGRect] { [] }
    func frostedPanels(_ item: ChatRowItem) -> [MaskPanel] { item.panels }
    func bubbleFrame(_ item: ChatRowItem) -> CGRect { item.bubbleFrame }
    func applyCutBands(_ item: ChatRowItem) {
        bubbleView.setCutBands(self.cutBands(item), incoming: item.isIncoming)

        let panels = self.frostedPanels(item)

        let isBlurred = !item.context.isLite(.blur)

        if let first = cutBandViews.first, (first is VisualEffect) != isBlurred {
            for view in cutBandViews {
                view.removeFromSuperview()
            }
            cutBandViews = []
        }

        while cutBandViews.count > panels.count {
            cutBandViews.removeLast().removeFromSuperview()
        }
        while cutBandViews.count < panels.count {
            let view: NSView = isBlurred ? VisualEffect(frame: .zero) : View(frame: .zero)
            rowView.addSubview(view, positioned: .below, relativeTo: bubbleView)
            cutBandViews.append(view)
        }

        guard !panels.isEmpty else {
            return
        }

        let origin = bubbleFrame(item).origin

        for (i, panel) in panels.enumerated() {
            let view = cutBandViews[i]
            view.frame = panel.rect.offsetBy(dx: origin.x, dy: origin.y)
            // `VisualEffect` tints through a sublayer, so a bare corner radius would leave the tint square.
            view.layer?.cornerRadius = panel.cornerRadius
            view.layer?.masksToBounds = true
            // The mask is always assigned, `nil` included: these views are recycled across rows, and a
            // silhouette left on a reused panel would eat most of it.
            if let view = view as? VisualEffect {
                view.bgColor = panel.blurTint
                // `maskContents` and not `maskImage`: the latter shapes only the material, leaving the
                // tint a full rectangle around the silhouette.
                view.maskContents = panel.mask
            } else if let view = view as? View {
                view.backgroundColor = panel.flatColor
                if let mask = panel.mask {
                    let maskLayer = view.layer?.mask ?? CALayer()
                    CATransaction.begin()
                    CATransaction.setDisableActions(true)
                    maskLayer.contents = mask
                    maskLayer.frame = view.bounds
                    view.layer?.mask = maskLayer
                    CATransaction.commit()
                } else {
                    view.layer?.mask = nil
                }
            }
        }
    }
}
