import Cocoa
import TGUIKit
final class ReferenceRow: RowEnvironment {
    override func set(item: TableRowItem, animated: Bool = false) {
        super.set(item: item, animated: animated)
        guard let item = item as? ChatListRowItem else { return }
             let unhideProgress = item.getHideProgress?()
             
             
             contentView.change(opacity: unhideProgress ?? (item.shouldHideContent ? 0 : 1), animated: animated)

             if let badgeNode = item.ctxShortBadgeNode, item.shouldHideContent , !item.hasLiveItems {
                 var presented: Bool = false
                 if badgeShortView == nil {
                     badgeShortView = View()
                     containerView.addSubview(badgeShortView!)
                     presented = true
                 }
                 badgeShortView?.setFrameSize(badgeNode.size)
                 badgeNode.aroundFill = _backgroundColor
                 badgeNode.view = badgeShortView
                 badgeNode.setNeedDisplay()
                 
                 let point = badgeShortPoint(item)

                 if presented {
                     badgeShortView?.setFrameOrigin(point)
                     if animated {
                         self.badgeShortView?.layer?.animateScaleSpring(from: 0.1, to: 1, duration: 0.4)
                         self.badgeShortView?.layer?.animateAlpha(from: 0, to: 1, duration: 0.2)
                     }
                 } else {
                     badgeShortView?.change(pos: point, animated: animated)
                     if let unhideProgress = unhideProgress {
                         badgeShortView?.change(opacity: 1 - unhideProgress, animated: animated)
                     } else {
                         badgeShortView?.change(opacity: 1, animated: animated)
                     }
                 }
             } else if let view = self.badgeShortView {
                 performSubviewRemoval(view, animated: animated, scale: true)
                 self.badgeShortView = nil
             }
             

        contentView.needsLayout = true
        revealActionInvoked = false
        contentView.needsDisplay = true
        needsLayout = true
        

    }

    public func updateHideProgress(animated: Bool) {
        if let item = self.item as? ChatListRowItem {
            self.set(item: item, animated: animated)
        }
    }
}
final class CandidateRow: RowEnvironment {
    override func set(item: TableRowItem, animated: Bool = false) {
        super.set(item: item, animated: animated)
        guard let item = item as? ChatListRowItem else { return }
             let unhideProgress = item.getHideProgress?()
             guard self.item === item else { return }
             
             
             contentView.change(opacity: unhideProgress ?? (item.shouldHideContent ? 0 : 1), animated: animated)

             if let badgeNode = item.ctxShortBadgeNode, item.shouldHideContent , !item.hasLiveItems {
                 var presented: Bool = false
                 if badgeShortView == nil {
                     badgeShortView = View()
                     containerView.addSubview(badgeShortView!)
                     presented = true
                 }
                 badgeShortView?.setFrameSize(badgeNode.size)
                 badgeNode.aroundFill = _backgroundColor
                 badgeNode.view = badgeShortView
                 badgeNode.setNeedDisplay()
                 
                 let point = badgeShortPoint(item)
                 let opacity = unhideProgress.map { 1 - $0 } ?? 1

                 if presented {
                     badgeShortView?.setFrameOrigin(point)
                     badgeShortView?.change(opacity: opacity, animated: false)
                     if animated {
                         self.badgeShortView?.layer?.animateScaleSpring(from: 0.1, to: 1, duration: 0.4)
                         self.badgeShortView?.layer?.animateAlpha(from: 0, to: opacity, duration: 0.2)
                     }
                 } else {
                     badgeShortView?.change(pos: point, animated: animated)
                     badgeShortView?.change(opacity: opacity, animated: animated)
                 }
             } else if let view = self.badgeShortView {
                 performSubviewRemoval(view, animated: animated, scale: true)
                 self.badgeShortView = nil
             }
             

        contentView.needsLayout = true
        revealActionInvoked = false
        contentView.needsDisplay = true
        needsLayout = true
        

    }

    public func updateHideProgress(animated: Bool) {
        guard let item = self.item as? ChatListRowItem else { return }
        guard item.context.layout == item.splitState else {
            self.set(item: item, animated: animated)
            return
        }
        let progress = item.getHideProgress?()
        guard self.item === item else { return }
        contentView.change(opacity: progress ?? (item.shouldHideContent ? 0 : 1), animated: animated)
        badgeShortView?.change(opacity: progress.map { 1 - $0 } ?? 1, animated: animated)
    }
}
final class ReferenceController: ControllerEnvironment {
    func getSwipeProgress() -> CGFloat? {
        if let swipeState = swipeState {
            switch swipeState {
            case .swiping, .success, .start:
                return swipeState.delta / (frame.width - 70)
            default:
                return nil
            }
        }
        return nil
    }
    override func updateSwipingState(_ state: SwipeState, controller: ControllerTarget, isPrevious: Bool) -> Void {
        
        if isPrevious, controller.stake.keepLeft > 0 {
            self.genericView.updateSwipingState(state, controller: controller)
            self.swipeState = state
            
            genericView.tableView.enumerateViews(with: { view in
                if let view = view as? ReferenceRow {
                    let animated: Bool
                    switch swipeState {
                    case .swiping, .success, .start:
                        animated = false
                    default:
                        animated = true
                    }
                    view.updateHideProgress(animated: animated)
                }
                return true
            })

            if let progress = getSwipeProgress() {
                genericView.backgroundView.layer?.opacity = Float(1 - progress)
            }
        }
    }
}
final class CandidateController: ControllerEnvironment {
    func getSwipeProgress() -> CGFloat? {
        if let swipeState = swipeState {
            switch swipeState {
            case .swiping, .success, .start:
                return swipeState.delta / (frame.width - 70)
            default:
                return nil
            }
        }
        return nil
    }
    override func updateSwipingState(_ state: SwipeState, controller: ControllerTarget, isPrevious: Bool) -> Void {
        
        if isPrevious, controller.stake.keepLeft > 0 {
            self.genericView.updateSwipingState(state, controller: controller)
            self.swipeState = state
            
            genericView.tableView.enumerateExistingItemViews(with: { _, view in
                if let view = view as? CandidateRow {
                    let animated: Bool
                    switch swipeState {
                    case .swiping, .success, .start:
                        animated = false
                    default:
                        animated = true
                    }
                    view.updateHideProgress(animated: animated)
                }
            })

            if let progress = getSwipeProgress() {
                genericView.backgroundView.layer?.opacity = Float(1 - progress)
            }
        }
    }
}
