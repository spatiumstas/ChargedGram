import Cocoa
import TGUIKit

final class TintCache {
    static let shared = TintCache()

    struct Key: Hashable {
        let source: ObjectIdentifier
        let color: CGColor
        let colorHash: CFHashCode
        let width: CGFloat
        let height: CGFloat
        let scale: CGFloat
        let flipVertical: Bool
        let flipHorizontal: Bool

        static func ==(lhs: Key, rhs: Key) -> Bool {
            lhs.source == rhs.source && lhs.width == rhs.width && lhs.height == rhs.height && lhs.scale == rhs.scale && lhs.flipVertical == rhs.flipVertical && lhs.flipHorizontal == rhs.flipHorizontal && CFEqual(lhs.color, rhs.color)
        }

        func hash(into hasher: inout Hasher) {
            hasher.combine(source)
            hasher.combine(width)
            hasher.combine(height)
            hasher.combine(scale)
            hasher.combine(flipVertical)
            hasher.combine(flipHorizontal)
            hasher.combine(colorHash)
        }
    }

    final class Entry {
        weak var source: CGImage?
        let output: CGImage
        let cost: Int

        init(source: CGImage, output: CGImage) {
            self.source = source
            self.output = output
            self.cost = output.bytesPerRow * output.height
        }
    }

    let lock = NSLock()
    var settings: DeviceGraphicsContextSettings?
    var entries: [Key: Entry] = [:]
    var order: [Key?] = Array(repeating: nil, count: 64)
    var first = 0
    var count = 0
    var retainedBytes = 0

    func image(_ source: NSImage, color: NSColor? = nil, bottomColor: NSColor? = nil, flipVertical: Bool = false, flipHorizontal: Bool = false, scale: CGFloat = System.backingScale, zoom: CGFloat = 1) -> CGImage {
        guard let color = color, bottomColor == nil, zoom == 1, color.type == .componentBased, source.size.width <= 64, source.size.height <= 64 else {
            return source.referencePrecomposed(color, bottomColor: bottomColor, flipVertical: flipVertical, flipHorizontal: flipHorizontal, scale: scale, zoom: zoom)
        }
        let resolvedScale = scale.isZero ? System.backingScale : scale
        var imageRect = CGRect(origin: .zero, size: source.size)
        let bitmap = source.cgImage(forProposedRect: &imageRect, context: nil, hints: nil)!
        let resolvedColor = color.cgColor
        let key = Key(source: ObjectIdentifier(bitmap), color: resolvedColor, colorHash: CFHash(resolvedColor), width: source.size.width, height: source.size.height, scale: resolvedScale, flipVertical: flipVertical, flipHorizontal: flipHorizontal)
        let settings = DeviceGraphicsContextSettings.shared
        lock.lock()
        if self.settings != settings {
            entries.removeAll(keepingCapacity: true)
            order = Array(repeating: nil, count: 64)
            first = 0
            count = 0
            retainedBytes = 0
            self.settings = settings
        }
        if let entry = entries[key], entry.source === bitmap {
            lock.unlock()
            return entry.output
        }
        lock.unlock()

        let drawingContext = DrawingContext(size: source.size, scale: resolvedScale, clear: true)
        drawingContext.withFlippedContext(horizontal: flipHorizontal, vertical: flipVertical) { context in
            let rect = CGRect(origin: .zero, size: drawingContext.size)
            context.interpolationQuality = .high
            context.clear(rect)
            context.clip(to: rect, mask: bitmap)
            context.setFillColor(key.color)
            context.fill(rect)
        }
        let image = drawingContext.generateImage()!
        let cost = image.bytesPerRow * image.height
        guard cost <= 64 * 1024 else { return image }
        lock.lock()
        defer { lock.unlock() }
        guard self.settings == settings, DeviceGraphicsContextSettings.shared == settings else { return image }
        if let entry = entries[key], entry.source === bitmap { return entry.output }
        if let replaced = entries[key] {
            retainedBytes -= replaced.cost
            entries[key] = Entry(source: bitmap, output: image)
            retainedBytes += cost
            while retainedBytes > 1024 * 1024 { evictFirst() }
            return image
        }
        while count >= 64 || retainedBytes + cost > 1024 * 1024 { evictFirst() }
        entries[key] = Entry(source: bitmap, output: image)
        order[(first + count) % order.count] = key
        count += 1
        retainedBytes += cost
        return image
    }

    private func evictFirst() {
        if let key = order[first], let entry = entries.removeValue(forKey: key) { retainedBytes -= entry.cost }
        order[first] = nil
        first = (first + 1) % order.count
        count -= 1
    }
}
