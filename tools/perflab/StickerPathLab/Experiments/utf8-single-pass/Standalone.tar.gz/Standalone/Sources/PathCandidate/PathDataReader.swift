import Foundation
import Cocoa

final class PathDataReader {
    private var current: UInt8?
    private var previous: UInt8?
    private let input: String.UTF8View
    private var position: String.UTF8View.Index

    private static let spaces: Set<UInt8> = Set("\n\r\t ,".utf8)

    init(input: String) {
        self.input = input.utf8
        self.position = input.utf8.startIndex
    }

    public func read() -> [PathSegment] {
        readNext()
        var segments = [PathSegment]()
        while readSegments(into: &segments) {}
        return segments
    }

    private func readSegments(into result: inout [PathSegment]) -> Bool {
        if let type = readSegmentType() {
            let argCount = getArgCount(segment: type)
            if argCount == 0 {
                result.append(PathSegment(type: type))
                return true
            }
            let data: [Double]
            if type == .a || type == .A {
                data = readDataOfASegment()
            } else {
                data = readData()
            }
            var index = 0
            var isFirstSegment = true
            while index < data.count {
                let end = index + argCount
                if end > data.count {
                    break
                }
                var currentType = type
                if type == .M && !isFirstSegment {
                    currentType = .L
                }
                if type == .m && !isFirstSegment {
                    currentType = .l
                }
                result.append(PathSegment(type: currentType, data: Array(data[index..<end])))
                isFirstSegment = false
                index = end
            }
            return true
        }
        return false
    }

    private func readData() -> [Double] {
        var data = [Double]()
        while true {
            skipSpaces()
            if let value = readNum() {
                data.append(value)
            } else {
                return data
            }
        }
    }

    private func readDataOfASegment() -> [Double] {
        let argCount = getArgCount(segment: .A)
        var data: [Double] = []
        var index = 0
        while true {
            skipSpaces()
            let value: Double?
            let indexMod = index % argCount
            if indexMod == 3 || indexMod == 4 {
                value = readFlag()
            } else {
                value = readNum()
            }
            guard let doubleValue = value else {
                return data
            }
            data.append(doubleValue)
            index += 1
        }
        return data
    }

    private func skipSpaces() {
        var currentCharacter = current
        while let character = currentCharacter, Self.spaces.contains(character) {
            currentCharacter = readNext()
        }
    }

    private func readFlag() -> Double? {
        guard let ch = current else {
            return .none
        }
        readNext()
        switch ch {
        case 48:
            return 0
        case 49:
            return 1
        default:
            return .none
        }
    }

    fileprivate func readNum() -> Double? {
        guard let ch = current else {
            return .none
        }

        guard ch >= 48 && ch <= 57 || ch == 46 || ch == 45 else {
            return .none
        }

        let start = input.index(before: position)
        let negative = ch == 45
        var isInteger = ch != 46
        var magnitude: UInt64 = 0
        var digits = 0
        if ch >= 48 && ch <= 57 {
            magnitude = UInt64(ch - 48)
            digits = 1
        }
        var hasDot = ch == 46
        while let next = readDigit(&hasDot) {
            if isInteger && next >= 48 && next <= 57 && digits < 15 {
                magnitude = magnitude * 10 + UInt64(next - 48)
                digits += 1
            } else {
                isInteger = false
            }
        }
        if isInteger && digits != 0 {
            return negative ? -Double(magnitude) : Double(magnitude)
        }
        let end = current == nil ? position : input.index(before: position)
        return Double(String(decoding: input[start..<end], as: UTF8.self))
    }

    fileprivate func readDigit(_ hasDot: inout Bool) -> UInt8? {
        if let ch = readNext() {
            if (ch >= 48 && ch <= 57) || ch == 101 || (previous == 101 && ch == 45) {
                return ch
            } else if ch == 46 && !hasDot {
                hasDot = true
                return ch
            }
        }
        return nil
    }

    @discardableResult
    private func readNext() -> UInt8? {
        previous = current
        if position == input.endIndex {
            current = nil
        } else {
            current = input[position]
            input.formIndex(after: &position)
        }
        return current
    }

    private func readSegmentType() -> PathSegment.SegmentType? {
        while true {
            if let type = getPathSegmentType() {
                readNext()
                return type
            }
            if readNext() == nil {
                return nil
            }
        }
    }

    fileprivate func getPathSegmentType() -> PathSegment.SegmentType? {
        if let ch = current {
            switch ch {
            case 77:
                return .M
            case 109:
                return .m
            case 76:
                return .L
            case 108:
                return .l
            case 67:
                return .C
            case 99:
                return .c
            case 81:
                return .Q
            case 113:
                return .q
            case 65:
                return .A
            case 97:
                return .a
            case 122, 90:
                return .z
            case 72:
                return .H
            case 104:
                return .h
            case 86:
                return .V
            case 118:
                return .v
            case 83:
                return .S
            case 115:
                return .s
            case 84:
                return .T
            case 116:
                return .t
            default:
                break
            }
        }
        return nil
    }

    fileprivate func getArgCount(segment: PathSegment.SegmentType) -> Int {
        switch segment {
        case .H, .h, .V, .v:
            return 1
        case .M, .m, .L, .l, .T, .t:
            return 2
        case .S, .s, .Q, .q:
            return 4
        case .C, .c:
            return 6
        case .A, .a:
            return 7
        default:
            return 0
        }
    }
}
