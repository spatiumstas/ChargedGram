import Cocoa
open class PathSegment: Equatable {
    public enum SegmentType {
        case M
        case L
        case C
        case Q
        case A
        case z
        case H
        case V
        case S
        case T
        case m
        case l
        case c
        case q
        case a
        case h
        case v
        case s
        case t
        case E
        case e
    }
    
    public let type: SegmentType
    public let data: [Double]

    public init(type: PathSegment.SegmentType = .M, data: [Double] = []) {
        self.type = type
        self.data = data
    }

    open func isAbsolute() -> Bool {
        switch type {
        case .M, .L, .H, .V, .C, .S, .Q, .T, .A, .E:
            return true
        default:
            return false
        }
    }

    public static func == (lhs: PathSegment, rhs: PathSegment) -> Bool {
        return lhs.type == rhs.type && lhs.data == rhs.data
    }
}

func renderPath(_ segments: [PathSegment], context: CGContext) {
    var currentPoint: CGPoint?
    var cubicPoint: CGPoint?
    
    func M(_ x: Double, y: Double) {
        let point = CGPoint(x: CGFloat(x), y: CGFloat(y))
        context.move(to: point)
        setInitPoint(point)
    }
    
    func m(_ x: Double, y: Double) {
        if let cur = currentPoint {
            let next = CGPoint(x: CGFloat(x) + cur.x, y: CGFloat(y) + cur.y)
            context.move(to: next)
            setInitPoint(next)
        } else {
            M(x, y: y)
        }
    }
    
    func L(_ x: Double, y: Double) {
        lineTo(CGPoint(x: CGFloat(x), y: CGFloat(y)))
    }
    
    func l(_ x: Double, y: Double) {
        if let cur = currentPoint {
            lineTo(CGPoint(x: CGFloat(x) + cur.x, y: CGFloat(y) + cur.y))
        } else {
            L(x, y: y)
        }
    }
    
    func H(_ x: Double) {
        if let cur = currentPoint {
            lineTo(CGPoint(x: CGFloat(x), y: CGFloat(cur.y)))
        }
    }
    
    func h(_ x: Double) {
        if let cur = currentPoint {
            lineTo(CGPoint(x: CGFloat(x) + cur.x, y: CGFloat(cur.y)))
        }
    }
    
    func V(_ y: Double) {
        if let cur = currentPoint {
            lineTo(CGPoint(x: CGFloat(cur.x), y: CGFloat(y)))
        }
    }
    
    func v(_ y: Double) {
        if let cur = currentPoint {
            lineTo(CGPoint(x: CGFloat(cur.x), y: CGFloat(y) + cur.y))
        }
    }

    func lineTo(_ p: CGPoint) {
        context.addLine(to: p)
        setPoint(p)
    }
    
    func c(_ x1: Double, y1: Double, x2: Double, y2: Double, x: Double, y: Double) {
        if let cur = currentPoint {
            let endPoint = CGPoint(x: CGFloat(x) + cur.x, y: CGFloat(y) + cur.y)
            let controlPoint1 = CGPoint(x: CGFloat(x1) + cur.x, y: CGFloat(y1) + cur.y)
            let controlPoint2 = CGPoint(x: CGFloat(x2) + cur.x, y: CGFloat(y2) + cur.y)
            context.addCurve(to: endPoint, control1: controlPoint1, control2: controlPoint2)
            setCubicPoint(endPoint, cubic: controlPoint2)
        }
    }
    
    func C(_ x1: Double, y1: Double, x2: Double, y2: Double, x: Double, y: Double) {
        let endPoint = CGPoint(x: CGFloat(x), y: CGFloat(y))
        let controlPoint1 = CGPoint(x: CGFloat(x1), y: CGFloat(y1))
        let controlPoint2 = CGPoint(x: CGFloat(x2), y: CGFloat(y2))
        context.addCurve(to: endPoint, control1: controlPoint1, control2: controlPoint2)
        setCubicPoint(endPoint, cubic: controlPoint2)
    }
    
    func s(_ x2: Double, y2: Double, x: Double, y: Double) {
        if let cur = currentPoint {
            let nextCubic = CGPoint(x: CGFloat(x2) + cur.x, y: CGFloat(y2) + cur.y)
            let next = CGPoint(x: CGFloat(x) + cur.x, y: CGFloat(y) + cur.y)
            
            let xy1: CGPoint
            if let curCubicVal = cubicPoint {
                xy1 = CGPoint(x: CGFloat(2 * cur.x) - curCubicVal.x, y: CGFloat(2 * cur.y) - curCubicVal.y)
            } else {
                xy1 = cur
            }
            context.addCurve(to: next, control1: xy1, control2: nextCubic)
            setCubicPoint(next, cubic: nextCubic)
        }
    }
    
    func S(_ x2: Double, y2: Double, x: Double, y: Double) {
        if let cur = currentPoint {
            let nextCubic = CGPoint(x: CGFloat(x2), y: CGFloat(y2))
            let next = CGPoint(x: CGFloat(x), y: CGFloat(y))
            let xy1: CGPoint
            if let curCubicVal = cubicPoint {
                xy1 = CGPoint(x: CGFloat(2 * cur.x) - curCubicVal.x, y: CGFloat(2 * cur.y) - curCubicVal.y)
            } else {
                xy1 = cur
            }
            context.addCurve(to: next, control1: xy1, control2: nextCubic)
            setCubicPoint(next, cubic: nextCubic)
        }
    }
    
    func z() {
        context.fillPath()
    }
    
    func setQuadrPoint(_ p: CGPoint, quadr: CGPoint) {
        currentPoint = p
        cubicPoint = nil
    }

    func setCubicPoint(_ p: CGPoint, cubic: CGPoint) {
        currentPoint = p
        cubicPoint = cubic
    }

    func setInitPoint(_ p: CGPoint) {
        setPoint(p)
    }

    func setPoint(_ p: CGPoint) {
        currentPoint = p
        cubicPoint = nil
    }
    
    for segment in segments {
        let data = segment.data
        switch segment.type {
            case .M:
                M(data[0], y: data[1])
                var index = 2
                while index + 1 < data.count {
                    L(data[index], y: data[index + 1])
                    index += 2
                }
            case .m:
                m(data[0], y: data[1])
                var index = 2
                while index + 1 < data.count {
                    l(data[index], y: data[index + 1])
                    index += 2
                }
            case .L:
                var index = 0
                while index + 1 < data.count {
                    L(data[index], y: data[index + 1])
                    index += 2
                }
            case .l:
                var index = 0
                while index + 1 < data.count {
                    l(data[index], y: data[index + 1])
                    index += 2
                }
            case .H:
                H(data[0])
            case .h:
                h(data[0])
            case .V:
                V(data[0])
            case .v:
                v(data[0])
            case .C:
                var index = 0
                while index + 5 < data.count {
                    C(data[index], y1: data[index + 1], x2: data[index + 2], y2: data[index + 3], x: data[index + 4], y: data[index + 5])
                    index += 6
                }
            case .c:
                var index = 0
                while index + 5 < data.count {
                    c(data[index], y1: data[index + 1], x2: data[index + 2], y2: data[index + 3], x: data[index + 4], y: data[index + 5])
                    index += 6
                }
            case .S:
                var index = 0
                while index + 3 < data.count {
                    S(data[index], y2: data[index + 1], x: data[index + 2], y: data[index + 3])
                    index += 4
                }
            case .s:
                var index = 0
                while index + 3 < data.count {
                    s(data[index], y2: data[index + 1], x: data[index + 2], y: data[index + 3])
                    index += 4
                }
            case .z:
                z()
            default:
                print("unknown")
                break
        }
    }
}
