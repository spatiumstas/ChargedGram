import Foundation

private let decodingMap = Array("AACAAAAHAAALMAAAQASTAVAAAZaacaaaahaaalmaaaqastava.az0123456789-,".utf8)

func decodeStickerThumbnailData(_ data: Data) -> String {
    if data.isEmpty {
        return "Mz"
    }
    var bytes = [UInt8]()
    bytes.reserveCapacity(data.count)
    bytes.append(UInt8(ascii: "M"))
    data.withUnsafeBytes { (input: UnsafeRawBufferPointer) in
        for byte in input {
            if byte >= 192 {
                bytes.append(decodingMap[Int(byte) - 192])
            } else {
                if byte >= 128 {
                    bytes.append(UInt8(ascii: ","))
                } else if byte >= 64 {
                    bytes.append(UInt8(ascii: "-"))
                }
                let value = byte & 63
                if value >= 10 {
                    bytes.append(UInt8(ascii: "0") + value / 10)
                }
                bytes.append(UInt8(ascii: "0") + value % 10)
            }
        }
    }
    bytes.append(UInt8(ascii: "z"))
    return String(decoding: bytes, as: UTF8.self)
}
