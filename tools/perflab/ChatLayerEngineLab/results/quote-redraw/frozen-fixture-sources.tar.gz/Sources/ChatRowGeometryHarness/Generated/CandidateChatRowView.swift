import Cocoa

public class CandidateChatRowView: GeometryView {
    var forwardAccessory: GeometryView?
    private var _cachedBubbleFrame: NSRect?
    private var _cachedContentFrame: NSRect?
    private var _cachedRightFrame: NSRect?
    public func invalidateFrameCache() {
        _cachedBubbleFrame = nil
        _cachedContentFrame = nil
        _cachedRightFrame = nil
    }

    public func cachedContentFrame(_ item: ChatRowItem) -> NSRect {
        if let cached = _cachedContentFrame { return cached }
        let result = contentFrame(item)
        _cachedContentFrame = result
        return result
    }

    public func bubbleFrame(_ item: ChatRowItem) -> NSRect {
        if let cached = _cachedBubbleFrame { return cached }
        let result = ChatRowGeometry.bubbleFrame(.init(item: item, rowWidth: frame.width))
        _cachedBubbleFrame = result
        return result
    }

    public func rightFrame(_ item: ChatRowItem) -> NSRect {
        if let cached = _cachedRightFrame { return cached }
        let result = ChatRowGeometry.timestampFrame(.init(item: item, rowWidth: frame.width, bubbleFrame: bubbleFrame(item), contentFrame: cachedContentFrame(item)))
        _cachedRightFrame = result
        return result
    }

    public func contentFrame(_ item: ChatRowItem) -> NSRect {
        return ChatRowGeometry.contentFrame(.init(item: item, bubbleFrame: item.isBubbled ? bubbleFrame(item) : .zero))
    }

    public func avatarFrame(_ item: ChatRowItem) -> NSRect {
        let isBubbled = item.isBubbled
        return ChatRowGeometry.avatarFrame(leftInset: item.leftInset, rowHeight: isBubbled ? item.height : 0, isBubbled: isBubbled)
    }

    public func captionFrame(_ item: ChatRowItem, caption: ChatRowItem.RowCaption) -> NSRect {
        let content = cachedContentFrame(item)
        let invertMedia = item.invertMedia
        return ChatRowGeometry.captionFrame(contentFrame: content, size: caption.layout.size, offset: caption.offset.y, invertedOffset: invertMedia ? caption.invertedOffset : 0, contentInset: caption.contentInset, innerInset: invertMedia ? 0 : item.defaultContentInnerInset, elementsInset: item.elementsContentInset, invertMedia: invertMedia, isBubbled: item.isBubbled)
    }

    public func replyFrame(_ item: ChatRowItem) -> NSRect {
        guard let reply = item.replyModel else { return .zero }
        return ChatRowGeometry.sideAccessoryFrame(.init(item: item, size: reply.size, offset: item.replyOffset, contentFrame: cachedContentFrame(item)))
    }

    public func topicLinkFrame(_ item: ChatRowItem) -> NSRect {
        guard let topic = item.topicLinkLayout else { return .zero }
        return ChatRowGeometry.sideAccessoryFrame(.init(item: item, size: topic.size, offset: item.topicLinkOffset, contentFrame: cachedContentFrame(item)))
    }

    public func namePoint(_ item: ChatRowItem) -> NSPoint {
        return ChatRowGeometry.authorPoint(.init(item: item, contentFrame: cachedContentFrame(item)))
    }

    public func forwardNamePoint(_ item: ChatRowItem) -> NSPoint {
        let accessoryWidth = item.isBubbled && !item.hasBubble ? forwardAccessory?.frame.width : nil
        let bubble = item.isBubbled && item.hasBubble ? bubbleFrame(item) : .zero
        let content = accessoryWidth != nil ? cachedContentFrame(item) : .zero
        return ChatRowGeometry.forwardNamePoint(.init(item: item, bubbleFrame: bubble, contentFrame: content, accessoryWidth: accessoryWidth))
    }

    public func forwardHeaderRect(_ item: ChatRowItem) -> CGRect {
        guard let header = item.forwardHeader else { return .zero }
        return ChatRowGeometry.forwardHeaderFrame(leftInset: item.defLeftInset, top: item.forwardHeaderInset.y, size: header.layoutSize)
    }

    public func forwardLineRect(_ item: ChatRowItem) -> CGRect {
        return ChatRowGeometry.forwardLineFrame(item: item, rowHeight: frame.height)
    }
}
