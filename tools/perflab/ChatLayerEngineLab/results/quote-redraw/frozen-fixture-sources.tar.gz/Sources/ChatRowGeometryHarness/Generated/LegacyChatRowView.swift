import Cocoa

public class LegacyChatRowView: GeometryView {
    var forwardAccessory: GeometryView?
    private var _cachedBubbleFrame: NSRect?
    private var _cachedContentFrame: NSRect?
    private var _cachedRightFrame: NSRect?
    public func invalidateFrameCache() {
        _cachedBubbleFrame = nil
        _cachedContentFrame = nil
        _cachedRightFrame = nil
    }

    public func cachedContentFrame(_ item: ChatRowItem) -> NSRect {
        if let cached = _cachedContentFrame { return cached }
        let result = contentFrame(item)
        _cachedContentFrame = result
        return result
    }

    public func bubbleFrame(_ item: ChatRowItem) -> NSRect {
        if let cached = _cachedBubbleFrame { return cached }
        var bubbleFrame = item.bubbleFrame
        bubbleFrame = NSMakeRect(item.isIncoming ? bubbleFrame.minX : frame.width - bubbleFrame.width - item.leftInset, bubbleFrame.minY, bubbleFrame.width, bubbleFrame.height)

        if item.chatInteraction.mode.isThreadMode, item.chatInteraction.chatLocation.threadMsgId == item.message?.id {
            bubbleFrame.origin.x = focus(NSMakeSize(bubbleFrame.size.width + 8, bubbleFrame.size.height)).minX
        }

        _cachedBubbleFrame = bubbleFrame
        return bubbleFrame
    }

    public func rightFrame(_ item: ChatRowItem) -> NSRect {
        if let cached = _cachedRightFrame { return cached }
        let rightSize = item.rightSize
        let bubbleFrame = self.bubbleFrame(item)
        let contentFrame = self.cachedContentFrame(item)
        var rect = NSMakeRect(frame.width - rightSize.width - item.rightInset, item.defaultContentTopOffset, rightSize.width, rightSize.height)
        let hasBubble = item.hasBubble
        if item.isBubbled {
            rect.origin = NSMakePoint((hasBubble ? bubbleFrame.maxX : contentFrame.maxX) - rightSize.width - item.bubbleContentInset - (item.isIncoming ? 0 : item.additionBubbleInset), bubbleFrame.maxY - rightSize.height - 6 - (item.isStateOverlayLayout && !hasBubble ? 2 : 0))

            if item.isStateOverlayLayout {
                if item is ChatVideoMessageItem {
                    rect.origin.y = contentFrame.maxY - rect.height - 3
                } else {
                    rect.origin.x += 5
                    rect.origin.y -= 2
                    rect.origin.x = max(20, rect.origin.x)
                }
            }
            if let item = item as? ChatVideoMessageItem {
                if item.canTranscribe, item.isIncoming {
                    rect.origin.x = contentFrame.maxX + 5
                } else {
                    rect.origin.x = item.isIncoming ? contentFrame.maxX - 40 : contentFrame.maxX - rightSize.width
                }
                rect.origin.y += 3
            }
            if let item = item as? ChatMessageItem {
                if item.containsBigEmoji {
                    rect.origin.y = bubbleFrame.maxY - rightSize.height
                } else if item.actionButtonText != nil {
                    if item.webpageLayout == nil {
                        rect.origin.y = bubbleFrame.maxY - rightSize.height - item.actionButtonHeight - 6;
                    }
                }
            }

            if item.hasBubble, let _ = item.commentsBubbleData {
                rect.origin.y -= ChatRowItem.channelCommentsBubbleHeight
            }

        }

        _cachedRightFrame = rect
        return rect
    }

    public func contentFrame(_ item: ChatRowItem) -> NSRect {
        var rect = NSMakeRect(item.contentOffset.x, item.contentOffset.y, item.contentSize.width, item.contentSize.height)
        if item.isBubbled {
            let bubbleFrame = self.bubbleFrame(item)
            if !item.isIncoming {
                rect.origin.x = bubbleFrame.minX + item.bubbleContentInset
            } else {
                rect.origin.x = bubbleFrame.minX + item.bubbleContentInset + item.additionBubbleInset
            }

        }
        return rect
    }

    public func avatarFrame(_ item: ChatRowItem) -> NSRect {
        var rect = NSMakeRect(item.leftInset, 6, 36, 36)

        if item.isBubbled {
            rect.origin.y = item.height - 36
        }

        return rect
    }

    public func captionFrame(_ item: ChatRowItem, caption: ChatRowItem.RowCaption) -> NSRect {
        var rect = self.cachedContentFrame(item)
        if item.invertMedia {
            rect.origin.y -= rect.height
            rect.origin.y -= (caption.invertedOffset)
            if !item.isBubbled {
                rect.origin.y -= caption.contentInset / 2
            }
        } else {
            rect.origin.y += (caption.offset.y + item.defaultContentInnerInset)
        }
        return NSMakeRect(rect.minX + item.elementsContentInset, rect.maxY, caption.layout.size.width, caption.layout.size.height)
    }

    public func replyFrame(_ item: ChatRowItem) -> NSRect {
        guard let reply = item.replyModel else {return NSZeroRect}

        let contentFrame = self.cachedContentFrame(item)

        var frame: NSRect = NSMakeRect(contentFrame.minX + item.elementsContentInset, item.replyOffset, reply.size.width, reply.size.height)
        if item.isBubbled, !item.hasBubble {
            if item.isIncoming {
                frame.origin.x = contentFrame.maxX + 6
            } else {
                frame.origin.x = contentFrame.minX - reply.size.width - 6
            }
            if item.isSharable || item.hasSource || item.commentsBubbleDataOverlay != nil {
                if item.isIncoming {
                    frame.origin.x += 46
                } else {
                    frame.origin.x -= 46
                }
            }
        }
        return frame
    }

    public func topicLinkFrame(_ item: ChatRowItem) -> NSRect {
        guard let value = item.topicLinkLayout else {return NSZeroRect}

        let contentFrame = self.cachedContentFrame(item)

        var frame: NSRect = NSMakeRect(contentFrame.minX + item.elementsContentInset, item.topicLinkOffset, value.size.width, value.size.height)
        if item.isBubbled, !item.hasBubble {
            if item.isIncoming {
                frame.origin.x = contentFrame.maxX + 6
            } else {
                frame.origin.x = contentFrame.minX - value.size.width - 6
            }
            if item.isSharable || item.hasSource || item.commentsBubbleDataOverlay != nil {
                if item.isIncoming {
                    frame.origin.x += 46
                } else {
                    frame.origin.x -= 46
                }
            }
        }
        return frame
    }

    public func namePoint(_ item: ChatRowItem) -> NSPoint {

        let contentFrame = self.cachedContentFrame(item)


        var point = NSMakePoint(contentFrame.minX, item.defaultContentTopOffset)
        if item.isBubbled {
            point.y -= (item.topInset - 1)
        } else {
            if item.forwardType != nil {
                point.x -= item.leftContentInset
            }
        }
        point.x += item.elementsContentInset
        return point

    }

    public func forwardNamePoint(_ item: ChatRowItem) -> NSPoint {

        var point = item.forwardNameInset

        if item.isBubbled && item.hasBubble {
            let bubbleFrame = self.bubbleFrame(item)
            point.x = bubbleFrame.minX + (item.isIncoming ? item.bubbleContentInset + item.additionBubbleInset : item.bubbleContentInset)
        } else if item.isBubbled, let forwardAccessory = forwardAccessory {
            let contentFrame = self.cachedContentFrame(item)
            point.x = item.isIncoming ? contentFrame.maxX : contentFrame.minX - forwardAccessory.frame.width
            point.y += 2
        }

        if item.authorText == nil {
            point.y -= 3
        }

        return point
    }

    public func forwardHeaderRect(_ item: ChatRowItem) -> CGRect {
        if let forwardHeader = item.forwardHeader {
            return NSMakeRect(item.defLeftInset, item.forwardHeaderInset.y, forwardHeader.layoutSize.width, forwardHeader.layoutSize.height)
        }
        return .zero
    }

    public func forwardLineRect(_ item: ChatRowItem) -> CGRect {
        if let fwdType = item.forwardType, !item.isBubbled {
            switch fwdType {
            case .ShortHeader:
                let height = frame.height - item.forwardNameInset.y - item.defaultContentTopOffset
                return NSMakeRect(item.defLeftInset, item.forwardNameInset.y, 2, height)
            case .FullHeader:
                return NSMakeRect(item.defLeftInset, item.forwardNameInset.y, 2, frame.height - item.forwardNameInset.y)
            case .Inside:
                 return NSMakeRect(item.defLeftInset, 0, 2, frame.height)
            case .Bottom:
                return NSMakeRect(item.defLeftInset, 0, 2, frame.height - item.defaultContentTopOffset)
            }
        }
        return .zero
    }

}
