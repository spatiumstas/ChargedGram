import Cocoa
import TGUIKit
import InputTextView

private final class FoldingInlineStickers {
    private var inlineStickerItemViews: [InlineStickerItemLayer.Key: SimpleLayer] = [:]
    var isEmpty: Bool { inlineStickerItemViews.isEmpty }

    func resetForContentChange(previous: TextViewLayout?, next: TextViewLayout?) {
        guard !inlineStickerItemViews.isEmpty else { return }
        func requiresRestart(_ layout: TextViewLayout?) -> Bool {
            return layout?.embeddedItems.contains { item in
                guard let sticker = item.value as? InlineStickerItem else { return false }
                if case .avatar = sticker.source { return true }
                return (sticker.playPolicy ?? .loop) != .loop
            } ?? false
        }
        if requiresRestart(previous) || requiresRestart(next) {
            for layer in inlineStickerItemViews.values { layer.removeFromSuperlayer() }
            inlineStickerItemViews.removeAll(keepingCapacity: true)
        }
    }

    func update(textView: TextView, context: any AccountContextProtocol, textLayout: TextViewLayout) {
        guard !textLayout.embeddedItems.isEmpty || !inlineStickerItemViews.isEmpty else { return }
        var validIds = InlineStickerKeyCollection()
        var index: Int = textView.hashValue
        
        let textColor: NSColor
        if textLayout.attributedString.length > 0 {
            var range:NSRange = NSMakeRange(NSNotFound, 0)
            let attrs = textLayout.attributedString.attributes(at: max(0, textLayout.attributedString.length - 1), effectiveRange: &range)
            textColor = attrs[.foregroundColor] as? NSColor ?? theme.colors.text
        } else {
            textColor = theme.colors.text
        }

        for item in textLayout.embeddedItems {
            if let stickerItem = item.value as? InlineStickerItem, item.rect.width > 10 {
                if case let .attribute(emoji) = stickerItem.source {
                    
                    let id = InlineStickerItemLayer.Key(id: emoji.fileId, index: index, color: emoji.color ?? textColor)
                    validIds.append(id)
                    
                    let rect = item.rect.insetBy(dx: 0, dy: 0)
                    
                    let view: InlineStickerItemLayer
                    if let current = self.inlineStickerItemViews[id] as? InlineStickerItemLayer, current.frame.size == rect.size && current.textColor == id.color {
                        view = current
                    } else {
                        self.inlineStickerItemViews[id]?.removeFromSuperlayer()
                        view = InlineStickerItemLayer(account: context.account, inlinePacksContext: context.inlinePacksContext, emoji: emoji, size: rect.size, playPolicy: stickerItem.playPolicy ?? .loop, textColor: textColor)
                        self.inlineStickerItemViews[id] = view
                        view.superview = textView
                        textView.addEmbeddedLayer(view)
                    }
                    index += 1
                    
                    view.frame = rect
                } else if case let .avatar(peer) = stickerItem.source {
                    let id = InlineStickerItemLayer.Key(id: peer.id.toInt64(), index: index)
                    validIds.append(id)
                    let rect = NSMakeRect(item.rect.minX, item.rect.minY + 3, item.rect.width - 3, item.rect.width - 3)
                   
                    let view: any InputInlineAvatarLayer
                    if let current = self.inlineStickerItemViews[id] as? any InputInlineAvatarLayer {
                        view = current
                    } else {
                        self.inlineStickerItemViews[id]?.removeFromSuperlayer()
                        view = InputTextViewHooks.shared.makeInlineAvatarLayer(context, rect, peer)
                        self.inlineStickerItemViews[id] = view
                        textView.addEmbeddedLayer(view)
                    }
                    index += 1
                    view.frame = rect
               }
                
            }
        }
        
        var removeKeys: [InlineStickerItemLayer.Key] = []
        for (key, itemLayer) in self.inlineStickerItemViews {
            if !validIds.contains(key) {
                removeKeys.append(key)
                itemLayer.removeFromSuperlayer()
            }
        }
        for key in removeKeys {
            self.inlineStickerItemViews.removeValue(forKey: key)
        }
    }

    func updateAnimatableContent(window: NSWindow?, isLite: Bool) {
        updateInlineStickerPlayback(inlineStickerItemViews.values, window: window, isLite: isLite)
    }
}

private protocol FoldingBlockInteractionState: AnyObject {
    var ignoreNextClick: Bool { get set }
}

private final class PlainTextBlock: NSObject, FoldingBlockInteractionState {
    var ignoreNextClick = false
    let textView = TextView()
    private(set) var currentLayout: FoldingTextLayout.ViewLayout?
    private var isLite: Bool = false
    fileprivate let inlineStickers = FoldingInlineStickers()
    private var animatableContentObserver: AnimatableContentObserver?

    func update(_ layout: FoldingTextLayout.ViewLayout, context: any AccountContextProtocol, transition: ContainedViewLayoutTransition) {
        self.currentLayout = layout
        self.isLite = context.isLite(.emoji)
        textView.canDrawBlocks = !layout.canReveal
        textView.update(layout.text)
        textView.set(mask: nil)
        textView.setIsShimmering(true, animated: transition.isAnimated)
        inlineStickers.update(textView: textView, context: context, textLayout: layout.text)
        updateAnimatableContent()
    }

    func updateListeners() {
        guard !inlineStickers.isEmpty else {
            animatableContentObserver = nil
            return
        }
        if animatableContentObserver == nil { animatableContentObserver = AnimatableContentObserver() }
        animatableContentObserver?.update(for: textView, target: self, selector: #selector(updateAnimatableContent), options: [.contentBounds, .documentFrame, .ownFrame])
    }

    @objc func updateAnimatableContent() {
        inlineStickers.updateAnimatableContent(window: textView.window, isLite: isLite)
    }
}

private enum FoldingBlock {
    case wrapper(WrapperView)
    case plain(PlainTextBlock)

    var view: NSView {
        switch self {
        case let .wrapper(view):
            return view
        case let .plain(block):
            return block.textView
        }
    }

    var inlineStickers: FoldingInlineStickers {
        switch self {
        case let .wrapper(view): return view.inlineStickers
        case let .plain(block): return block.inlineStickers
        }
    }

    var hasActiveContentAnimation: Bool {
        if case let .wrapper(view) = self { return view.hasActiveContentAnimation }
        return false
    }

    var interactionState: any FoldingBlockInteractionState {
        switch self {
        case let .wrapper(view): return view
        case let .plain(block): return block
        }
    }

    var textView: TextView {
        switch self {
        case let .wrapper(view):
            return view.textView
        case let .plain(block):
            return block.textView
        }
    }

    var currentLayout: FoldingTextLayout.ViewLayout? {
        switch self {
        case let .wrapper(view):
            return view.currentLayout
        case let .plain(block):
            return block.currentLayout
        }
    }

    var isPlain: Bool {
        if case .plain = self {
            return true
        }
        return false
    }

    static func isPlain(_ layout: FoldingTextLayout.ViewLayout) -> Bool {
        return !layout.text.hasBlockQuotes && !layout.canReveal
    }

    static func make(isPlain: Bool) -> FoldingBlock {
        return isPlain ? .plain(PlainTextBlock()) : .wrapper(WrapperView(frame: .zero))
    }
}

private final class WrapperView : View, FoldingBlockInteractionState {
    var ignoreNextClick = false
    
    
    let textView = TextView()
    private let mask: SimpleShapeLayer = SimpleShapeLayer()
    private var textMask: SimpleLayer?
    private var blockLayer: FoldingTextQuoteLayer?
    private var arrow: SimpleLayer?
    
    
    var currentLayout: FoldingTextLayout.ViewLayout?
    
    var isLite: Bool = false
    
    fileprivate let inlineStickers = FoldingInlineStickers()

    
    var hasActiveContentAnimation: Bool {
        return mask.animationKeys()?.isEmpty == false || arrow?.animationKeys()?.isEmpty == false
    }

    required init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        addSubview(textView)
        self.layer?.mask = mask
    }
    
    func update(_ layout: FoldingTextLayout.ViewLayout, isRevealed: Bool, context: any AccountContextProtocol, transition: ContainedViewLayoutTransition) {
        
        let previousLayout = self.currentLayout
        
        self.currentLayout = layout
        
        let isRevealed = layout.isRevealed
        
        self.isLite = context.isLite(.emoji)
        
        textView.canDrawBlocks = !layout.canReveal

        self.textView.update(layout.text)
        
        let size = layout.size
 
        
        
        let path = CGMutablePath()
        
        if layout.canReveal {
            path.addRoundedRect(in: size.bounds, cornerWidth: min(size.width / 2, 4), cornerHeight: min(size.height / 2, 4))
        } else {
            path.addRoundedRect(in: size.bounds, cornerWidth: 0, cornerHeight: 0)
        }
        
        
        if transition.isAnimated {
            let animation = mask.makeAnimation(from: self.mask.path ?? CGMutablePath(), to: path, keyPath: "path", timingFunction: transition.timingFunction, duration: transition.duration)
            mask.add(animation, forKey: "path")
        }
        mask.path = path
        
        self.layer?.masksToBounds = layout.text.hasBlockQuotes
        self.layer?.mask = layout.text.hasBlockQuotes ? mask : nil


        if layout.canReveal {
            let current: FoldingTextQuoteLayer
            if let layer = self.blockLayer {
                current = layer
            } else {
                current = FoldingTextQuoteLayer(frame: size.bounds)
                self.layer?.addSublayer(current)
                self.blockLayer = current
            }
            current.blockQuotes = layout.text.blockQuotes
            transition.updateFrame(layer: current, frame: layout.layoutSize.bounds)
            current.mask = mask
        } else {
            if let layer = self.blockLayer {
                performSublayerRemoval(layer, animated: transition.isAnimated)
                self.blockLayer = nil
            }
        }
        
        if !isRevealed {
            let current: SimpleLayer
            if let layer = self.textMask {
                current = layer
            } else {
                current = .init(frame: size.bounds)
                self.textMask = current
            }
            current.contents = layout.mask
            current.contentsGravity = .bottom
            current.frame = size.bounds
            if transition.isAnimated {
                delay(transition.duration, closure: { [weak self] in
                    self?.textView.set(mask: self?.textMask)
                })
            } else {
                self.textView.set(mask: current)
            }
        } else {
            self.textMask = nil
            self.textView.set(mask: nil)
        }
        
        if layout.canReveal {
            let current: SimpleLayer
            if let layer = self.arrow {
                current = layer
            } else {
                let s = NSMakeSize(10, 7)
                current = SimpleLayer(frame: NSMakeRect(size.width - s.width - 5, size.height - s.height - 6, s.width, s.height))
                self.arrow = current
                self.layer?.addSublayer(current)
            }
            current.anchorPoint = NSMakePoint(0, 0)
            current.contents = layout.isRevealed ? layout.arrowUp : layout.arrowDown
            
            if previousLayout?.isRevealed != layout.isRevealed, transition.isAnimated {
                current.animateContents()
            }
        } else if let arrow = self.arrow {
            performSublayerRemoval(arrow, animated: transition.isAnimated)
            self.arrow = nil
        }
        
        self.textView.setIsShimmering(true, animated: transition.isAnimated)
        
        self.updateInlineStickers(context: context, textLayout: layout.text)
        self.updateListeners()
        self.updateAnimatableContent()
        
        transition.updateFrame(view: self, frame: CGRect(origin: self.frame.origin, size: size))
        self.updateLayout(size: size, transition: transition)
    }
    
    func updateLayout(size: NSSize, transition: ContainedViewLayoutTransition) {
        if let arrow = arrow {
            transition.updateFrame(layer: arrow, frame: NSMakeRect(size.width - arrow.frame.width - 5, size.height - arrow.frame.height - 6, arrow.frame.width, arrow.frame.height))
        }
    }
    
    
    override func layout() {
        super.layout()
        self.updateLayout(size: self.frame.size, transition: .immediate)
    }

    required public init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    func updateInlineStickers(context: any AccountContextProtocol, textLayout: TextViewLayout) {
        inlineStickers.update(textView: textView, context: context, textLayout: textLayout)
    }
    
    
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        self.updateListeners()
        self.updateAnimatableContent()
    }
    override func viewDidMoveToSuperview() {
        super.viewDidMoveToSuperview()
        self.updateListeners()
        self.updateAnimatableContent()
    }
    
    @objc func updateAnimatableContent() -> Void {
        inlineStickers.updateAnimatableContent(window: window, isLite: isLite)
    }
    private var animatableContentObserver: AnimatableContentObserver?

    private func updateListeners() {
        guard !inlineStickers.isEmpty else {
            animatableContentObserver = nil
            return
        }
        if animatableContentObserver == nil { animatableContentObserver = AnimatableContentObserver() }
        animatableContentObserver?.update(for: self, target: self, selector: #selector(updateAnimatableContent), options: [.contentBounds, .documentFrame, .ownFrame])
    }

}


func makeCurrentBlock(quoted: Bool) -> BlockHarness {
    if quoted {
        let block = WrapperView(frame: .zero)
        return BlockHarness(owner: block, view: block, textView: block.textView, update: { layout, context in
            block.update(layout, isRevealed: layout.isRevealed, context: context, transition: .immediate)
        }, listeners: {
            block.viewDidMoveToSuperview()
        })
    } else {
        let block = PlainTextBlock()
        return BlockHarness(owner: block, view: block.textView, textView: block.textView, update: { layout, context in
            block.update(layout, context: context, transition: .immediate)
            block.updateListeners()
        }, listeners: { block.updateListeners() })
    }
}
