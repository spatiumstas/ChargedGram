import Cocoa
import TGUIKit

extension FoldingTextLayout {
    public var size: NSSize {
        var size: NSSize = .zero
        for block in blocks {
            if block.isRevealed {
                size.height += block.layoutSize.height
            } else {
                size.height += block.size.height
            }
            size.width = max(block.layoutSize.width, size.width)
        }
        
        if appendingAnimation, let last = blocks.last?.text.lines.last {
            let animSize = NSMakeSize(18, 18)
            if last.frame.maxX + animSize.width > size.width {
                if blocks.count == 1, blocks[0].text.lines.count == 1 {
                    size.width += animSize.width
                } else {
                    size.height += animSize.height
                }
            }
        }
        return size
    }
}
