import Cocoa
import TGUIKit

private let quoteIcon: CGImage = {
    return TelegramThemeHooks.shared.image(.iconQuote).precomposed(flipVertical: false)
}()

public final class FoldingTextQuoteLayer: SimpleLayer {
    private final class CopyIconCache {
        static let shared = CopyIconCache()

        private struct Key: Hashable {
            let source: ObjectIdentifier
            let color: CGColor
            let width: CGFloat
            let height: CGFloat
            let scale: CGFloat

            static func ==(lhs: Key, rhs: Key) -> Bool {
                return lhs.source == rhs.source && lhs.width == rhs.width && lhs.height == rhs.height && lhs.scale == rhs.scale && CFEqual(lhs.color, rhs.color)
            }

            func hash(into hasher: inout Hasher) {
                hasher.combine(source)
                hasher.combine(width)
                hasher.combine(height)
                hasher.combine(scale)
                hasher.combine(CFHash(color))
            }
        }

        private struct Entry {
            let source: CGImage
            let image: CGImage
        }

        private let lock = NSLock()
        private var settings: DeviceGraphicsContextSettings?
        private var images: [Key: Entry] = [:]
        private var order: [Key] = []

        func image(_ source: NSImage, color: NSColor, scale: CGFloat) -> CGImage {
            guard color.type == .componentBased else {
                return source.precomposed(color, flipVertical: true, scale: scale)
            }
            var rect = CGRect(origin: .zero, size: source.size)
            guard let bitmap = source.cgImage(forProposedRect: &rect, context: nil, hints: nil) else {
                return source.precomposed(color, flipVertical: true, scale: scale)
            }
            let key = Key(source: ObjectIdentifier(bitmap), color: color.cgColor, width: source.size.width, height: source.size.height, scale: scale)
            let settings = DeviceGraphicsContextSettings.shared
            lock.lock()
            if self.settings != settings {
                images.removeAll(keepingCapacity: true)
                order.removeAll(keepingCapacity: true)
                self.settings = settings
            }
            if let entry = images[key] {
                lock.unlock()
                return entry.image
            }
            lock.unlock()

            let drawingContext = DrawingContext(size: NSSize(width: key.width, height: key.height), scale: scale, clear: true)
            drawingContext.withFlippedContext(vertical: true) { context in
                let rect = CGRect(origin: .zero, size: drawingContext.size)
                context.interpolationQuality = .high
                context.clear(rect)
                context.clip(to: rect, mask: bitmap)
                context.setFillColor(key.color)
                context.fill(rect)
            }
            let image = drawingContext.generateImage()!
            guard bitmap.bytesPerRow * bitmap.height + image.bytesPerRow * image.height <= 16 * 1024 else { return image }
            lock.lock()
            defer { lock.unlock() }
            guard self.settings == settings, DeviceGraphicsContextSettings.shared == settings else { return image }
            if let entry = images[key] { return entry.image }
            if order.count == 16 {
                images.removeValue(forKey: order.removeFirst())
            }
            images[key] = Entry(source: bitmap, image: image)
            order.append(key)
            return image
        }
    }

    private struct DrawingState {
        private struct Quote {
            let frame: CGRect
            let main: NSColor
            let secondary: NSColor?
            let tertiary: NSColor?
            let isCode: Bool

            static func canCache(_ quote: TextViewBlockQuote) -> Bool {
                return quote.header == nil && quote.colors.main.type == .componentBased && (quote.colors.secondary?.type ?? .componentBased) == .componentBased && (quote.colors.tertiary?.type ?? .componentBased) == .componentBased
            }

            func matches(_ quote: TextViewBlockQuote) -> Bool {
                return Self.canCache(quote) && frame == quote.frame && main == quote.colors.main && secondary == quote.colors.secondary && tertiary == quote.colors.tertiary && isCode == quote.isCode
            }
        }

        private let quotes: [Quote]
        private let bounds: CGRect
        private let contentsScale: CGFloat
        private let systemScale: CGFloat
        private let settings: DeviceGraphicsContextSettings

        init?(_ layer: FoldingTextQuoteLayer) {
            guard layer.blockQuotes.allSatisfy(Quote.canCache) else { return nil }
            quotes = layer.blockQuotes.map { Quote(frame: $0.frame, main: $0.colors.main, secondary: $0.colors.secondary, tertiary: $0.colors.tertiary, isCode: $0.isCode) }
            bounds = layer.bounds
            contentsScale = layer.contentsScale
            systemScale = System.backingScale
            settings = DeviceGraphicsContextSettings.shared
        }

        func matches(_ layer: FoldingTextQuoteLayer) -> Bool {
            guard bounds == layer.bounds, contentsScale == layer.contentsScale, systemScale == System.backingScale, settings == DeviceGraphicsContextSettings.shared, quotes.count == layer.blockQuotes.count else { return false }
            for index in quotes.indices {
                if !quotes[index].matches(layer.blockQuotes[index]) { return false }
            }
            return true
        }
    }

    private var drawingState: DrawingState?

    public override var bounds: CGRect {
        didSet {
            if bounds != oldValue { setNeedsDisplay() }
        }
    }

    public override var contentsScale: CGFloat {
        didSet {
            if contentsScale != oldValue { setNeedsDisplay() }
        }
    }

    public var blockQuotes: [TextViewBlockQuote] = [] {
        didSet {
            if contents == nil || drawingState?.matches(self) != true {
                setNeedsDisplay()
            }
        }
    }

    public override func display() {
        let state = DrawingState(self)
        super.display()
        drawingState = contents == nil ? nil : state
    }
    public override func draw(in ctx: CGContext) {
        for blockQuote in blockQuotes {
            let radius: CGFloat = 3.0
            let lineWidth: CGFloat = 3.0


            let blockFrame = blockQuote.frame
            let blockColor = blockQuote.isCode ? blockQuote.colors.tertiary ?? blockQuote.colors.main : blockQuote.colors.main
            let tintColor = blockQuote.colors.main
            let secondaryTintColor = blockQuote.colors.secondary
            let tertiaryTintColor = blockQuote.colors.tertiary


            var bg = blockColor
            if blockQuote.isCode {
                bg = bg.darker(amount: 0.5).withAlphaComponent(0.5)
            } else {
                bg = bg.withAlphaComponent(0.1)
            }
            ctx.setFillColor(bg.cgColor)
            ctx.addPath(CGPath(roundedRect: blockFrame, cornerWidth: radius, cornerHeight: radius, transform: nil))
            ctx.fillPath()

            ctx.setFillColor(tintColor.cgColor)

            if !blockQuote.isCode {
                let iconSize = quoteIcon.backingSize
                let quoteRect = CGRect(origin: CGPoint(x: blockFrame.maxX - 4.0 - iconSize.width, y: blockFrame.minY + 4.0), size: iconSize)
                ctx.saveGState()
                ctx.translateBy(x: quoteRect.midX, y: quoteRect.midY)
                ctx.scaleBy(x: 1.0, y: -1.0)
                ctx.translateBy(x: -quoteRect.midX, y: -quoteRect.midY)
                ctx.clip(to: quoteRect, mask: quoteIcon)
                ctx.fill(quoteRect)
                ctx.restoreGState()
                ctx.resetClip()
            }


            drawBlockQuoteLine(ctx: ctx, blockFrame: blockFrame, radius: radius, lineWidth: lineWidth, tintColor: tintColor, secondaryTintColor: secondaryTintColor, tertiaryTintColor: tertiaryTintColor)

            if let header = blockQuote.header {
                let headerHeight = blockQuote.headerInset + 2
                ctx.setFillColor(blockQuote.colors.main.withAlphaComponent(0.2).cgColor)
                let rect = NSMakeRect(blockFrame.minX, blockFrame.minY, blockFrame.width, headerHeight)
                ctx.drawRoundedRect(rect: rect, topLeftRadius: radius, topRightRadius: radius)
                header.1.draw(CGRect(x: blockFrame.minX + 8, y: blockFrame.minY + (headerHeight - header.0.size.height) / 2 - 1, width: header.0.size.width, height: header.0.size.height), in: ctx, backingScaleFactor: System.backingScale, backgroundColor: .clear)
                let image = CopyIconCache.shared.image(TelegramThemeHooks.shared.image(.iconCopyCode), color: blockQuote.colors.main, scale: System.backingScale)
                ctx.draw(image, in: CGRect(origin: NSMakePoint(blockFrame.width - image.backingSize.width - 3, blockFrame.minY + (headerHeight - image.backingSize.height) / 2), size: image.backingSize))
            }
        }
    }
}

public func sharedFoldingQuoteIconForLab() -> CGImage { quoteIcon }

public final class OriginalRedrawQuoteLayer: SimpleLayer {
    private final class CopyIconCache {
        static let shared = CopyIconCache()

        private struct Key: Hashable {
            let source: ObjectIdentifier
            let color: CGColor
            let width: CGFloat
            let height: CGFloat
            let scale: CGFloat

            static func ==(lhs: Key, rhs: Key) -> Bool {
                return lhs.source == rhs.source && lhs.width == rhs.width && lhs.height == rhs.height && lhs.scale == rhs.scale && CFEqual(lhs.color, rhs.color)
            }

            func hash(into hasher: inout Hasher) {
                hasher.combine(source)
                hasher.combine(width)
                hasher.combine(height)
                hasher.combine(scale)
                hasher.combine(CFHash(color))
            }
        }

        private struct Entry {
            let source: CGImage
            let image: CGImage
        }

        private let lock = NSLock()
        private var settings: DeviceGraphicsContextSettings?
        private var images: [Key: Entry] = [:]
        private var order: [Key] = []

        func image(_ source: NSImage, color: NSColor, scale: CGFloat) -> CGImage {
            guard color.type == .componentBased else {
                return source.precomposed(color, flipVertical: true, scale: scale)
            }
            var rect = CGRect(origin: .zero, size: source.size)
            guard let bitmap = source.cgImage(forProposedRect: &rect, context: nil, hints: nil) else {
                return source.precomposed(color, flipVertical: true, scale: scale)
            }
            let key = Key(source: ObjectIdentifier(bitmap), color: color.cgColor, width: source.size.width, height: source.size.height, scale: scale)
            let settings = DeviceGraphicsContextSettings.shared
            lock.lock()
            if self.settings != settings {
                images.removeAll(keepingCapacity: true)
                order.removeAll(keepingCapacity: true)
                self.settings = settings
            }
            if let entry = images[key] {
                lock.unlock()
                return entry.image
            }
            lock.unlock()

            let drawingContext = DrawingContext(size: NSSize(width: key.width, height: key.height), scale: scale, clear: true)
            drawingContext.withFlippedContext(vertical: true) { context in
                let rect = CGRect(origin: .zero, size: drawingContext.size)
                context.interpolationQuality = .high
                context.clear(rect)
                context.clip(to: rect, mask: bitmap)
                context.setFillColor(key.color)
                context.fill(rect)
            }
            let image = drawingContext.generateImage()!
            guard bitmap.bytesPerRow * bitmap.height + image.bytesPerRow * image.height <= 16 * 1024 else { return image }
            lock.lock()
            defer { lock.unlock() }
            guard self.settings == settings, DeviceGraphicsContextSettings.shared == settings else { return image }
            if let entry = images[key] { return entry.image }
            if order.count == 16 {
                images.removeValue(forKey: order.removeFirst())
            }
            images[key] = Entry(source: bitmap, image: image)
            order.append(key)
            return image
        }
    }

    public var blockQuotes: [TextViewBlockQuote] = [] {
        didSet {
            setNeedsDisplay()
        }
    }
    public override func draw(in ctx: CGContext) {
        for blockQuote in blockQuotes {
            let radius: CGFloat = 3.0
            let lineWidth: CGFloat = 3.0


            let blockFrame = blockQuote.frame
            let blockColor = blockQuote.isCode ? blockQuote.colors.tertiary ?? blockQuote.colors.main : blockQuote.colors.main
            let tintColor = blockQuote.colors.main
            let secondaryTintColor = blockQuote.colors.secondary
            let tertiaryTintColor = blockQuote.colors.tertiary


            var bg = blockColor
            if blockQuote.isCode {
                bg = bg.darker(amount: 0.5).withAlphaComponent(0.5)
            } else {
                bg = bg.withAlphaComponent(0.1)
            }
            ctx.setFillColor(bg.cgColor)
            ctx.addPath(CGPath(roundedRect: blockFrame, cornerWidth: radius, cornerHeight: radius, transform: nil))
            ctx.fillPath()

            ctx.setFillColor(tintColor.cgColor)

            if !blockQuote.isCode {
                let iconSize = quoteIcon.backingSize
                let quoteRect = CGRect(origin: CGPoint(x: blockFrame.maxX - 4.0 - iconSize.width, y: blockFrame.minY + 4.0), size: iconSize)
                ctx.saveGState()
                ctx.translateBy(x: quoteRect.midX, y: quoteRect.midY)
                ctx.scaleBy(x: 1.0, y: -1.0)
                ctx.translateBy(x: -quoteRect.midX, y: -quoteRect.midY)
                ctx.clip(to: quoteRect, mask: quoteIcon)
                ctx.fill(quoteRect)
                ctx.restoreGState()
                ctx.resetClip()
            }


            drawBlockQuoteLine(ctx: ctx, blockFrame: blockFrame, radius: radius, lineWidth: lineWidth, tintColor: tintColor, secondaryTintColor: secondaryTintColor, tertiaryTintColor: tertiaryTintColor)

            if let header = blockQuote.header {
                let headerHeight = blockQuote.headerInset + 2
                ctx.setFillColor(blockQuote.colors.main.withAlphaComponent(0.2).cgColor)
                let rect = NSMakeRect(blockFrame.minX, blockFrame.minY, blockFrame.width, headerHeight)
                ctx.drawRoundedRect(rect: rect, topLeftRadius: radius, topRightRadius: radius)
                header.1.draw(CGRect(x: blockFrame.minX + 8, y: blockFrame.minY + (headerHeight - header.0.size.height) / 2 - 1, width: header.0.size.width, height: header.0.size.height), in: ctx, backingScaleFactor: System.backingScale, backgroundColor: .clear)
                let image = CopyIconCache.shared.image(TelegramThemeHooks.shared.image(.iconCopyCode), color: blockQuote.colors.main, scale: System.backingScale)
                ctx.draw(image, in: CGRect(origin: NSMakePoint(blockFrame.width - image.backingSize.width - 3, blockFrame.minY + (headerHeight - image.backingSize.height) / 2), size: image.backingSize))
            }
        }
    }
}
