import Cocoa
import TGUIKit

final class BaselineRow: RowEnvironment {

    override func set(item:TableRowItem, animated:Bool = false) {
        invalidateFrameCache()
        let previousItem = self.item as? ChatRowItem

        super.set(item: item, animated: animated)


        if let item = previousItem {
            item.chatInteraction.remove(observer: self)
        }
        guard let item = item as? ChatRowItem else {
            return
        }

        if self.animatedView != nil && self.animatedView?.stableId != item.stableId {
            self.animatedView?.removeFromSuperview()
            self.animatedView = nil
        }

        let animated = animated && item.presentation.bubbled == previousItem?.presentation.bubbled


        if previousItem?.message?.id != item.message?.id {
            updateBackground(animated: false, item: item, clean: true)
        }

        renderLayoutType(item, animated: animated)


        item.chatInteraction.add(observer: self)

        updateSelectingState(selectingMode:item.chatInteraction.presentation.selectionState != nil, item: item, needUpdateColors: false)

        rightView.set(item:item, animated:animated)
        fillTopicLink(item, animated: animated)
        fillReply(item, animated: animated)
        fillName(item, animated: animated)
        fillForward(item, animated: animated)
        fillForwardHeader(item, animated: animated)
        fillForwardLine(item, animated: animated)
        fillPhoto(item, animated: animated)
        fillStatus(item, animated: animated)
        fillPsaButton(item, animated: animated)
        fillShareView(item, animated: animated)
        fillReactions(item, animated: animated)
        fillReplyMarkup(item, animated: animated)
        fillCaption(item, animated: animated)
        fillFactCheck(item, animated: animated)
        fillChannelComments(item, animated: animated)


    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
         if let item = self.item as? ChatRowItem {
            if window == nil {
                item.chatInteraction.remove(observer: self)
            } else {
                item.chatInteraction.add(observer: self)
            }
        }

    }

    deinit {
        }

    override func isEqual(to other: Notifable) -> Bool {
        if let other = other as? BaselineRow {
            return self == other
        }
        return false
    }

    override func notify(with value: Any, oldValue: Any, animated:Bool) {


        let transition: ContainedViewLayoutTransition = animated ? .animated(duration: 0.2, curve: .easeOut) : .immediate

        if let value = value as? ChatPresentationInterfaceState, let oldValue = oldValue as? ChatPresentationInterfaceState {
            if (value.selectionState != oldValue.selectionState) {
                updateSelectingState(!NSIsEmptyRect(visibleRect), selectingMode:value.selectionState != nil, item: self.item as? ChatRowItem, needUpdateColors: true)

                updateLayout(size: frame.size, transition: transition)
            } else if let item = item as? ChatRowItem, let message = item.message {
                if value.selectionState?.selectedIds.contains(message.id) != oldValue.selectionState?.selectedIds.contains(message.id) {
                    if let selectionState = value.selectionState {
                        selectingView?.set(selected: selectionState.selectedIds.contains(message.id), animated: !NSIsEmptyRect(visibleRect))
                        updateColors()
                        updateLayout(size: frame.size, transition: transition)
                    }
                }
            }
        }

    }
}
final class CandidateRow: RowEnvironment {
    private weak var observedInteraction: ChatInteraction?
    private var isPreparingItem: Bool = false
    override func set(item:TableRowItem, animated:Bool = false) {
        invalidateFrameCache()
        let previousItem = self.item as? ChatRowItem

        super.set(item: item, animated: animated)


        if observedInteraction !== (item as? ChatRowItem)?.chatInteraction {
            updateInteractionObserver(nil)
        }
        guard let item = item as? ChatRowItem else {
            return
        }
        isPreparingItem = true

        if self.animatedView != nil && self.animatedView?.stableId != item.stableId {
            self.animatedView?.removeFromSuperview()
            self.animatedView = nil
        }

        let animated = animated && item.presentation.bubbled == previousItem?.presentation.bubbled


        if previousItem?.message?.id != item.message?.id {
            updateBackground(animated: false, item: item, clean: true)
        }

        renderLayoutType(item, animated: animated)

        updateInteractionObserver(item.chatInteraction)

        updateSelectingState(selectingMode:item.chatInteraction.presentation.selectionState != nil, item: item, needUpdateColors: false)

        rightView.set(item:item, animated:animated)
        fillTopicLink(item, animated: animated)
        fillReply(item, animated: animated)
        fillName(item, animated: animated)
        fillForward(item, animated: animated)
        fillForwardHeader(item, animated: animated)
        fillForwardLine(item, animated: animated)
        fillPhoto(item, animated: animated)
        fillStatus(item, animated: animated)
        fillPsaButton(item, animated: animated)
        fillShareView(item, animated: animated)
        fillReactions(item, animated: animated)
        fillReplyMarkup(item, animated: animated)
        fillCaption(item, animated: animated)
        fillFactCheck(item, animated: animated)
        fillChannelComments(item, animated: animated)


    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        updateInteractionObserver(window == nil ? nil : (item as? ChatRowItem)?.chatInteraction)

    }

    deinit {
        contentView.removeAllSubviews()
        observedInteraction?.remove(observer: self)
    }

    override func isEqual(to other: Notifable) -> Bool {
        if let other = other as? CandidateRow {
            return self == other
        }
        return false
    }

    override func notify(with value: Any, oldValue: Any, animated:Bool) {
        guard !isPreparingItem else { return }

        let transition: ContainedViewLayoutTransition = animated ? .animated(duration: 0.2, curve: .easeOut) : .immediate

        if let value = value as? ChatPresentationInterfaceState, let oldValue = oldValue as? ChatPresentationInterfaceState {
            if (value.selectionState != oldValue.selectionState) {
                updateSelectingState(!NSIsEmptyRect(visibleRect), selectingMode:value.selectionState != nil, item: self.item as? ChatRowItem, needUpdateColors: true)

                updateLayout(size: frame.size, transition: transition)
            } else if let item = item as? ChatRowItem, let message = item.message {
                if value.selectionState?.selectedIds.contains(message.id) != oldValue.selectionState?.selectedIds.contains(message.id) {
                    if let selectionState = value.selectionState {
                        selectingView?.set(selected: selectionState.selectedIds.contains(message.id), animated: !NSIsEmptyRect(visibleRect))
                        updateColors()
                        updateLayout(size: frame.size, transition: transition)
                    }
                }
            }
        }

    }

    private func updateInteractionObserver(_ interaction: ChatInteraction?) {
        if interaction != nil {
            isPreparingItem = false
        }
        guard observedInteraction !== interaction else { return }
        observedInteraction?.remove(observer: self)
        observedInteraction = interaction
        interaction?.add(observer: self)
    }
}
