import Cocoa

open class TableStickItem: TableRowItem {

    let _stableId = Int64(arc4random())
    open override var stableId: AnyHashable {
        return _stableId
    }
    
    open override func isEqual(_ object: Any?) -> Bool {
        return self === object as? TableStickItem
    }
    
    open var singletonItem: Bool {
        return false
    }
    
    open var isFixed: Bool {
        return false
    }
    
    open var headerHeight: CGFloat {
        return height
    }
    
    open override var height: CGFloat {
        return 30.0
    }
    
    public required override init(_ initialSize:NSSize) {
        super.init(initialSize)
    }
    
    open override func viewClass() -> AnyClass {
        return TableStickView.self
    }
    
    open override var canBeAnchor: Bool {
        return false
    }
    
    
}
