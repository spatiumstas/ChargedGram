import Cocoa

public enum  LinearProgressAlignment {
    case bottom
    case center
    case top
}

public class LinearProgressControl: Control {

    public override var mouseDownCanMoveWindow: Bool { false }

    public var hasMinumimVisibility: Bool = false
    
    private var progressLayer:SimpleLayer!
    private var fetchingLayer:SimpleLayer!
    private var previewLayer:SimpleLayer!

    private var fetchingLayers:[SimpleLayer] = []
    
    private var containerView:View!
    
    private var _progress:CGFloat = 0
    private var progress:CGFloat {
        get {
            return scrubblingTempState ?? _progress
        }
        set {
            _progress = newValue
            updatePreviewLayout()
        }
    }
    
    private var fetchingProgress: CGFloat = 0
    private var fetchingProgressRanges: [Range<CGFloat>] = []

    public var previewProgress: CGFloat? {
        didSet {
            updatePreviewLayout()
        }
    }
    public var previewColor: NSColor = .clear {
        didSet {
            previewLayer?.backgroundColor = previewColor.cgColor
        }
    }
    
    public var progressHeight:CGFloat
    public var onUserChanged:((Float)->Void)?
    public var onHoverUpdated:((CGFloat?)->Void)?
    
    public var onLiveScrobbling:((Float?)->Void)?

    public var startScrobbling:(()->Void)?
    public var endScrobbling:(()->Void)?

    public var insets: NSEdgeInsets = NSEdgeInsets() {
        didSet {
            needsLayout = true
        }
    }
    public var alignment: LinearProgressAlignment = .bottom
    public var liveScrobbling: Bool = true
    
    private var scrubber: ImageButton? = nil
    
    private(set) public var scrubblingTempState: CGFloat? {
        didSet {
            needsLayout = true
            self.progressLayer.removeAllAnimations()
            self.scrubber?.layer?.removeAllAnimations()
            updatePreviewLayout()
        }
    }
    
    private var progressCornerRadius: CGFloat?
    public var cornerRadius: CGFloat = 0 {
        didSet {
            progressCornerRadius = cornerRadius
            updateCornerRadii()
            self.layer?.cornerRadius = cornerRadius
        }
    }
    
    public var scrubberImage: CGImage? {
        didSet {
            if let scrubberImage = scrubberImage {
                if scrubber == nil {
                    scrubber = ImageButton()
                    scrubber?.userInteractionEnabled = false
                    scrubber?.autohighlight = false
                    scrubber!.set(image: scrubberImage, for: .Normal)
                    _ = scrubber!.sizeToFit()
                    addSubview(scrubber!)
                } else {
                    scrubber!.set(image: scrubberImage, for: .Normal)
                    _ = scrubber!.sizeToFit()
                }
                needsLayout = true
            } else {
                scrubber?.removeFromSuperview()
                scrubber = nil
            }
        }
    }
    public var roundCorners: Bool = false {
        didSet {
            updateCornerRadii()
        }
    }

    private func updateCornerRadii() {
        containerView.layer?.cornerRadius = roundCorners ? containerView.frame.height / 2 : 0
        progressLayer.cornerRadius = progressCornerRadius ?? (roundCorners ? progressLayer.frame.height / 2 : 0)
        fetchingLayer.cornerRadius = roundCorners ? fetchingLayer.frame.height / 2 : 0
        previewLayer.cornerRadius = 0

        for view in fetchingLayers {
            view.cornerRadius = roundCorners ? view.frame.height / 2 : 0
        }
    }
    
    public var currentValue: CGFloat {
        return progress
    }

    private func updatePreviewLayout() {
        guard let previewLayer = previewLayer, let containerView = containerView, let previewProgress else {
            self.previewLayer?.isHidden = true
            return
        }

        let clampedPreviewProgress = min(max(previewProgress.isNaN ? 0 : previewProgress, 0), 1)
        let currentProgress = min(max(progress.isNaN ? 0 : progress, 0), 1)
        let previewWidth = floorToScreenPixels(backingScaleFactor, containerView.frame.width * clampedPreviewProgress)
        previewLayer.frame = NSMakeRect(0, 0, previewWidth, progressHeight)
        previewLayer.isHidden = clampedPreviewProgress <= currentProgress
    }
    
    
    public override func isAccessibilityElement() -> Bool {
        guard TGUIKitAccessibility.isEnabled, !isAccessibilityDecorative, !isHidden else {
            return false
        }
        return onUserChanged != nil || super.isAccessibilityElement()
    }

    public override func accessibilityRole() -> NSAccessibility.Role? {
        guard isAccessibilityElement() else {
            return super.accessibilityRole()
        }
        return onUserChanged != nil ? .slider : .progressIndicator
    }

    public override var accessibilityDefaultLabel: String? {
        return localizedString("VoiceOver.Common.PlaybackPosition")
    }

    public override func accessibilityValue() -> Any? {
        if let value = super.accessibilityValue() {
            return value
        }
        guard TGUIKitAccessibility.isEnabled else {
            return nil
        }
        return "\(Int((progress * 100).rounded()))%"
    }

    public override func accessibilityPerformIncrement() -> Bool {
        return accessibilityAdjust(by: 0.05)
    }

    public override func accessibilityPerformDecrement() -> Bool {
        return accessibilityAdjust(by: -0.05)
    }

    public override func accessibilityPerformPress() -> Bool {
        return onUserChanged != nil ? false : super.accessibilityPerformPress()
    }

    private func accessibilityAdjust(by delta: CGFloat) -> Bool {
        guard TGUIKitAccessibility.isEnabled, isEnabled, let onUserChanged = onUserChanged else {
            return false
        }
        let value = min(max(_progress + delta, 0), 1)
        set(progress: value)
        onUserChanged(Float(value))
        return true
    }

    public override func mouseDragged(with event: NSEvent) {
        super.mouseDragged(with: event)
        updateHoverValue()
        if let onUserChanged = onUserChanged, isEnabled {
            let location = containerView.convert(event.locationInWindow, from: nil)
           // if location.x >= 0 && location.x <= frame.width {
            let progress = min(max(Float(max(location.x, 0) / containerView.frame.width), 0), 1)
            if liveScrobbling {
                onUserChanged(progress)
            } else {
                self.scrubblingTempState = CGFloat(progress)
                self.onLiveScrobbling?(progress)
            }
           // }
        }
    }
    
    
    public override func mouseDown(with event: NSEvent) {
        scrubblingTempState = nil
        self.started = true
        self.startScrobbling?()
        if let _ = onUserChanged, !liveScrobbling, isEnabled {
            let location = containerView.convert(event.locationInWindow, from: nil)
            let progress = min(max(CGFloat(max(location.x, 0) / containerView.frame.width), 0), 1)
            self.scrubblingTempState = progress
            self.onLiveScrobbling?(nil)
            // }
        } else if !userInteractionEnabled {
            //super.mouseDown(with: event)
        }
    }
    
    private var started: Bool = false
    
    public var hasTemporaryState: Bool {
        return scrubblingTempState != nil || started
    }

    public override func mouseUp(with event: NSEvent) {
        scrubblingTempState = nil
        self.started = false
        self.endScrobbling?()
        if let onUserChanged = onUserChanged, isEnabled {
            let location = containerView.convert(event.locationInWindow, from: nil)
            let progress = min(max(Float(max(location.x, 0) / containerView.frame.width), 0), 1)
            onUserChanged(progress)
            self.onLiveScrobbling?(nil)
        } 
    }
    
    public var interactiveValue:Float {
        if let window = window {
            let location = containerView.convert(window.mouseLocationOutsideOfEventStream, from: nil)
            return Float(location.x / containerView.frame.width)
        }
        return 0
    }
    
    open override func updateTrackingAreas() {
        super.updateTrackingAreas();
        
        
        if let trackingArea = trackingArea {
            self.removeTrackingArea(trackingArea)
        }
        
        trackingArea = nil
        
        if let _ = window {
            let options:NSTrackingArea.Options = [NSTrackingArea.Options.cursorUpdate, NSTrackingArea.Options.mouseEnteredAndExited, NSTrackingArea.Options.mouseMoved, NSTrackingArea.Options.enabledDuringMouseDrag, NSTrackingArea.Options.activeInKeyWindow,NSTrackingArea.Options.inVisibleRect]
            self.trackingArea = NSTrackingArea(rect: self.bounds, options: options, owner: self, userInfo: nil)
            
            self.addTrackingArea(self.trackingArea!)
        }
    }
    
    deinit {
        if let trackingArea = self.trackingArea {
            self.removeTrackingArea(trackingArea)
        }
    }
    
    public override var style: ControlStyle {
        set {
            self.progressLayer.backgroundColor = newValue.foregroundColor.cgColor
            super.style = newValue
        }
        get {
            return super.style
        }
    }
    
    public var containerBackground: NSColor = .clear {
        didSet {
            containerView.backgroundColor = containerBackground
        }
    }
    
    public var fetchingColor: NSColor = presentation.colors.grayTransparent {
        didSet {
            self.fetchingLayer.backgroundColor = fetchingColor.cgColor
            for fetchView in fetchingLayers {
                fetchView.backgroundColor = fetchingColor.cgColor
            }
        }
    }
    
    
    private func preparedAnimation(keyPath: String, from: NSValue, to: NSValue, duration: Double, beginTime: Double?, offset: Double, speed: Float, repeatForever: Bool = false) -> CAAnimation {
        let animation = CABasicAnimation(keyPath: keyPath)
        animation.fromValue = from
        animation.toValue = to
        animation.duration = duration
        animation.fillMode = .both
        animation.speed = speed
        animation.timeOffset = offset
        animation.isAdditive = false
        if let beginTime = beginTime {
            animation.beginTime = beginTime
        }
        return animation
    }
    
    private struct AppliedPlaybackAnimation {
        let seekId: Int?
        let duration: Double
        let beginTime: Double
        let offset: Double
        let speed: Float
        let containerWidth: CGFloat
        let scrubberFrame: NSRect

        func predictedPosition(at time: Double) -> Double {
            return self.offset + (time - self.beginTime) * Double(self.speed)
        }
    }

    private var appliedPlaybackAnimation: AppliedPlaybackAnimation?

    private static let widthAnimationKey = "trackWidth"

    private func presentationWidth(of layer: CALayer) -> CGFloat? {
        guard layer.animation(forKey: LinearProgressControl.widthAnimationKey) != nil, let presentation = layer.presentation() else {
            return nil
        }
        return presentation.bounds.width
    }

    private func setWidth(_ layer: CALayer, _ width: CGFloat, animated: Bool, duration: Double, timingFunction: CAMediaTimingFunctionName) {
        let from = presentationWidth(of: layer) ?? layer.frame.width
        layer.frame.size = NSMakeSize(max(0, width), max(0, progressHeight))
        if animated, abs(from - width) > CGFloat.ulpOfOne {
            let animation = layer.makeAnimation(from: NSNumber(value: Double(from)), to: NSNumber(value: Double(width)), keyPath: "bounds.size.width", timingFunction: timingFunction, duration: duration)
            layer.add(animation, forKey: LinearProgressControl.widthAnimationKey)
        } else {
            layer.removeAnimation(forKey: LinearProgressControl.widthAnimationKey)
        }
    }

    private func centerTrack(_ layer: CALayer) {
        layer.frame.origin = NSMakePoint(0, round((containerView.frame.height - layer.frame.height) / 2))
    }

    private func isPlaybackAnimationAttached() -> Bool {
        if progressLayer.animation(forKey: LinearProgressControl.widthAnimationKey) == nil {
            return false
        }
        if let scrubber = scrubber, scrubber.layer?.animation(forKey: "position") == nil {
            return false
        }
        return true
    }

    public func set(progress:CGFloat, animated:Bool, duration: Double, beginTime: Double?, offset: Double, speed: Float, seekId: Int? = nil, repeatForever: Bool = false) {
        let progress:CGFloat = min(progress.isNaN ? 1 : progress, 1)
        self.progress = progress

        centerTrack(progressLayer)

        if animated, scrubblingTempState == nil {
            let updated = AppliedPlaybackAnimation(seekId: seekId, duration: duration, beginTime: beginTime ?? CACurrentMediaTime(), offset: offset, speed: speed, containerWidth: containerView.frame.width, scrubberFrame: scrubber?.frame ?? .zero)

            if let applied = appliedPlaybackAnimation, isPlaybackAnimationAttached(), applied.seekId == updated.seekId, applied.speed == updated.speed, applied.duration.isEqual(to: updated.duration), applied.containerWidth == updated.containerWidth, applied.scrubberFrame == updated.scrubberFrame {
                let now = CACurrentMediaTime()
                if abs(applied.predictedPosition(at: now) - updated.predictedPosition(at: now)) < 0.2 {
                    updateFetchingRanges(animated)
                    return
                }
            }

            progressLayer.add(preparedAnimation(keyPath: "bounds.size.width", from: NSNumber(value: Double(0)), to: NSNumber(value: Double(containerView.frame.width)), duration: duration, beginTime: beginTime, offset: offset, speed: speed), forKey: LinearProgressControl.widthAnimationKey)
            if let scrubber = scrubber {
                scrubber.layer?.add(preparedAnimation(keyPath: "position", from: NSValue(point: NSMakePoint(containerView.frame.minX - scrubber.frame.width / 2, scrubber.frame.minY)), to: NSValue(point: NSMakePoint(containerView.frame.maxX - scrubber.frame.width / 2, scrubber.frame.minY)), duration: duration, beginTime: beginTime, offset: offset, speed: speed), forKey: "position")
            }
            appliedPlaybackAnimation = updated
        } else {
            appliedPlaybackAnimation = nil
            scrubber?.layer?.removeAllAnimations()
            progressLayer.removeAllAnimations()
            set(progress: progress)
        }

        updateFetchingRanges(animated)
    }
    
    public override var frame: NSRect {
        didSet {
            layout()
        }
    }
    public func set(progress:CGFloat, animated:Bool = false, duration: Double = 0.2, timingFunction: CAMediaTimingFunctionName = .linear, bounce: Bool = false) {
        let progress:CGFloat = progress.isNaN ? 1 : progress
        self.appliedPlaybackAnimation = nil
        self.progress = progress
        let size = NSMakeSize(floorToScreenPixels(backingScaleFactor, max(containerView.frame.width * self.progress, hasMinumimVisibility ? progressHeight : 0)), progressHeight)

        if !animated {
            scrubber?.layer?.removeAnimation(forKey: "position")
        }
        
        setWidth(progressLayer, size.width, animated: animated, duration: duration, timingFunction: timingFunction)
        if let scrubber = scrubber {
            scrubber.change(pos: NSMakePoint(max(0, min(containerView.frame.minX + size.width - scrubber.frame.width / 2, containerView.frame.maxX - scrubber.frame.width)), scrubber.frame.minY), animated: animated, timingFunction: timingFunction)
        }
        centerTrack(progressLayer)
        
        updateFetchingRanges(animated)
    }
    
    public func set(fetchingProgress: CGFloat, animated:Bool = false, duration: Double = 0.2) {
        let fetchingProgress:CGFloat = fetchingProgress.isNaN ? 1 : fetchingProgress
        self.fetchingProgress = fetchingProgress
        let size = NSMakeSize(floorToScreenPixels(backingScaleFactor, containerView.frame.width * fetchingProgress), progressHeight)
        setWidth(fetchingLayer, size.width, animated: animated, duration: duration, timingFunction: .linear)
        
        centerTrack(fetchingLayer)
    }
    
    public func set(fetchingProgressRanges: [Range<CGFloat>], animated: Bool = true) {
        self.fetchingProgressRanges = fetchingProgressRanges
        updateFetchingRanges(animated)
    }
    
    private func updateFetchingRanges(_ animated: Bool) {
        let fetchingProgressRanges = self.fetchingProgressRanges.filter({$0.contains(self.currentValue)})
        
        if self.fetchingLayers.count == fetchingProgressRanges.count {
            
        } else if self.fetchingLayers.count > fetchingProgressRanges.count {
            while self.fetchingLayers.count != fetchingProgressRanges.count {
                self.fetchingLayers.removeLast().removeFromSuperlayer()
            }
        } else if self.fetchingLayers.count < fetchingProgressRanges.count {
            while self.fetchingLayers.count != fetchingProgressRanges.count {
                let layer = makeTrackLayer(color: fetchingColor)
                self.fetchingLayers.append(layer)
                containerView.layer?.insertSublayer(layer, below: previewLayer)
            }
        }
        
        for i in 0 ..< fetchingProgressRanges.count {
            let range = fetchingProgressRanges[i]
            let view = self.fetchingLayers[i]
            let width = (range.upperBound - range.lowerBound) * containerView.frame.width
            setWidth(view, width, animated: animated, duration: 0.2, timingFunction: .linear)
            view.frame.origin = NSMakePoint(range.lowerBound * containerView.frame.width, floorToScreenPixels(backingScaleFactor, (containerView.frame.height - progressHeight) / 2))
            view.cornerRadius = roundCorners ? view.frame.height / 2 : 0
        }
    }

    

    public init(progressHeight:CGFloat = 4) {
        self.progressHeight = progressHeight
        super.init(frame: NSMakeRect(0, 0, 0, progressHeight))
        
        initialize()
    }
    
    public override func layout() {
        super.layout()

        let previousContainerWidth = containerView.frame.width
        
        switch alignment {
        case .bottom:
            containerView.frame = NSMakeRect(insets.left, frame.height - progressHeight, frame.width - insets.left - insets.right, progressHeight)
        case .top:
            containerView.frame = NSMakeRect(insets.left, 0, frame.width - insets.left - insets.right, progressHeight)
        case .center:
            containerView.frame = NSMakeRect(insets.left, floorToScreenPixels(backingScaleFactor, (frame.height - progressHeight) / 2), frame.width - insets.left - insets.right, progressHeight)
        }

        if containerView.frame.width != previousContainerWidth {
            appliedPlaybackAnimation = nil
            progressLayer.removeAnimation(forKey: LinearProgressControl.widthAnimationKey)
            fetchingLayer.removeAnimation(forKey: LinearProgressControl.widthAnimationKey)
            scrubber?.layer?.removeAnimation(forKey: "position")
            for view in fetchingLayers {
                view.removeAnimation(forKey: LinearProgressControl.widthAnimationKey)
            }
        }
        
        let progressWidth = floorToScreenPixels(backingScaleFactor, max(containerView.frame.width * self.progress, hasMinumimVisibility ? progressHeight : 0))
        progressLayer.frame = NSMakeRect(0, 0, progressWidth, progressHeight)

        let fetchingWidth = floorToScreenPixels(backingScaleFactor, containerView.frame.width * fetchingProgress)
        fetchingLayer.frame = NSMakeRect(0, 0, max(0, fetchingWidth), max(0, progressHeight))

        let visibleFetchingRanges = fetchingProgressRanges.filter({ $0.contains(currentValue) })
        for (index, range) in visibleFetchingRanges.enumerated() where index < fetchingLayers.count {
            let width = (range.upperBound - range.lowerBound) * containerView.frame.width
            fetchingLayers[index].frame = NSMakeRect(range.lowerBound * containerView.frame.width, 0, width, progressHeight)
        }

        updatePreviewLayout()
        updateCornerRadii()
        
        
        if let scrubber = scrubber {
            scrubber.centerY(x: max(0, min(containerView.frame.minX + progressWidth - scrubber.frame.width / 2, containerView.frame.maxX - scrubber.frame.width)))
        }

    }
    

    private func makeTrackLayer(color: NSColor) -> SimpleLayer {
        let layer = SimpleLayer()
        layer.anchorPoint = .zero
        layer.edgeAntialiasingMask = []
        layer.frame = NSMakeRect(0, 0, 0, progressHeight)
        layer.backgroundColor = color.cgColor
        layer.masksToBounds = true
        layer.isOpaque = true
        if #available(macOS 10.15, *) {
            layer.cornerCurve = .continuous
        }
        return layer
    }

    private func initialize() {
        containerView = View(frame: NSMakeRect(0, 0, 0, progressHeight))
        addSubview(containerView)
        fetchingLayer = makeTrackLayer(color: style.foregroundColor)
        containerView.layer?.addSublayer(fetchingLayer)
        previewLayer = makeTrackLayer(color: previewColor)
        previewLayer.isHidden = true
        containerView.layer?.addSublayer(previewLayer)
        progressLayer = makeTrackLayer(color: style.foregroundColor)
        containerView.layer?.addSublayer(progressLayer)
        userInteractionEnabled = false
        containerView.isEventLess = true
    }

    public var highlightOnHover: Bool = true
    
    private func updateCursor() {
        if mouseInside() && onUserChanged != nil, style.highlightColor != .clear, isEnabled {
            if highlightOnHover {
                set(background: style.highlightColor.withAlphaComponent(0.2), for: .Hover)
            }
        } else {
            set(background: style.backgroundColor, for: .Hover)
        }
    }
    
    public override func mouseEntered(with event: NSEvent) {
        super.mouseEntered(with: event)
        updateHoverValue()
        updateCursor()
    }
    
    public override func mouseExited(with event: NSEvent) {
        super.mouseExited(with: event)
        onHoverUpdated?(nil)
        updateCursor()
    }
    
    public override func mouseMoved(with event: NSEvent) {
        super.mouseMoved(with: event)
        updateHoverValue()
        updateCursor()
    }

    private func updateHoverValue() {
        guard let window = window, containerView.frame.width > 0 else {
            onHoverUpdated?(nil)
            return
        }
        let location = containerView.convert(window.mouseLocationOutsideOfEventStream, from: nil)
        onHoverUpdated?(min(max(location.x / containerView.frame.width, 0), 1))
    }
    
    required public init(frame frameRect: NSRect) {
        self.progressHeight = frameRect.height
        super.init(frame:frameRect)
        initialize()
    }
    
    required public init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
