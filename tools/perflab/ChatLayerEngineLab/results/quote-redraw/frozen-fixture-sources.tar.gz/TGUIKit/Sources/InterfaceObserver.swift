import Cocoa

public protocol Notifable : AnyObject {
    
    func notify(with value:Any, oldValue:Any, animated:Bool) -> Void
    
    func isEqual(to other:Notifable) -> Bool

}

private class WeakNotifable {
    
    public private(set) weak var value:Notifable?
    
    public init(value:Notifable?) {
        self.value = value
    }
}

open class InterfaceObserver : NSObject  {
    private var observers:[WeakNotifable] = []

    public func add(observer:Notifable) {
        for other in observers {
            if let value = other.value {
                if value.isEqual(to: observer) {
                    return
                }
            }
            
        }
        observers.append(WeakNotifable(value: observer))
    }
    
    public func remove(observer:Notifable) {
        var copy:[WeakNotifable] = []
        for observer in observers {
            copy.append(observer)
        }
        
        for i in stride(from: copy.count - 1, through: 0, by: -1) {
            if let value = copy[i].value {
                if value.isEqual(to: observer)  {
                    observers.remove(at: i)
                }
            } else {
                observers.remove(at: i)
            }
           
        }
    }
    
    public func notifyObservers(value:Any, oldValue:Any, animated:Bool) {
        for observer in observers.reversed() {
            if let observer = observer.value {
                observer.notify(with: value, oldValue: oldValue, animated: animated)
            }
        }
    }
    
}
