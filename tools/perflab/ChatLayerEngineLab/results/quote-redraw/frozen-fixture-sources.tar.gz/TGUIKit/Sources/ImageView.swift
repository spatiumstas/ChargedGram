import Cocoa


public enum ImageViewTransition {
    case `default`
    case modern
}

open class ImageView: NSView {

    
    public var isEventLess: Bool = false
    
    public var animationTransition: ImageViewTransition = .default
    open var animates:Bool = false
    
    open var image:CGImage? {
        didSet {
            if animates {
                let wasImage = self.layer?.contents != nil
                self.layer?.contents = image
                if !wasImage {
                    self.layer?.animateAlpha(from: 0, to: 1, duration: 0.2)
                } else {
                    animate()
                }
            } else if image != nil || self.layer?.contents != nil {
                self.layer?.contents = image
            }
        }
    }
    
    open var nsImage:NSImage? {
        didSet {
            let wasImage = self.layer?.contents != nil
            self.layer?.contents = nsImage
            if animates {
                if !wasImage {
                    self.layer?.animateAlpha(from: 0, to: 1, duration: 0.2)
                } else {
                    animate()
                }
            }
        }
    }

    open var contentGravity: CALayerContentsGravity = .center {
        didSet {
            layer?.contentsGravity = contentGravity
        }
    }
    
    open func sizeToFit() {
        if let image = self.image {
            setFrameSize(image.backingSize)
        }
    }
    
    open override func hitTest(_ point: NSPoint) -> NSView? {
        if isEventLess {
            let view = super.hitTest(point)
            if let view = view as? View {
                if view.isEventLess || view === self {
                    return nil
                }
            }
            if let view = view as? ImageView {
                if view.isEventLess || view === self {
                    return nil
                }
            }
            return view
        } else {
            return super.hitTest(point)
        }
    }

    open override func acceptsFirstMouse(for event: NSEvent?) -> Bool {
        return true
    }

    open override func mouseUp(with event: NSEvent) {
        super.mouseUp(with: event)
    }
    
    override public init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        self.wantsLayer = true
        layerContentsRedrawPolicy = .never
        layer?.masksToBounds = true
    }
    init() {
        super.init(frame: .zero)
        self.wantsLayer = true
        layerContentsRedrawPolicy = .never
        layer?.masksToBounds = true
    }
    
    
    public var isAccessibilityDecorative: Bool = false

    open override func isAccessibilityElement() -> Bool {
        guard TGUIKitAccessibility.isEnabled, !isHidden, !isAccessibilityDecorative, let label = super.accessibilityLabel() else {
            return false
        }
        return !label.isEmpty
    }

    open override func accessibilityRole() -> NSAccessibility.Role? {
        return isAccessibilityElement() ? .image : super.accessibilityRole()
    }

    required public init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    open func animate() -> Void {
        let  animation = CABasicAnimation(keyPath: "contents")
        animation.duration = 0.2
        self.layer?.add(animation, forKey: "contents")
    }

    override open func viewDidChangeBackingProperties() {
        if self.window != nil {
        }
    }
    
    open func change(pos position: NSPoint, animated: Bool, _ save:Bool = true, removeOnCompletion: Bool = true, duration:Double = 0.2, timingFunction: CAMediaTimingFunctionName = CAMediaTimingFunctionName.easeOut, completion:((Bool)->Void)? = nil) -> Void  {
        super._change(pos: position, animated: animated, save, removeOnCompletion: removeOnCompletion, duration: duration, timingFunction: timingFunction, completion: completion)
    }
    
    open func change(size: NSSize, animated: Bool, _ save:Bool = true, removeOnCompletion: Bool = true, duration:Double = 0.2, timingFunction: CAMediaTimingFunctionName = CAMediaTimingFunctionName.easeOut, completion:((Bool)->Void)? = nil) {
        super._change(size: size, animated: animated, save, removeOnCompletion: removeOnCompletion, duration: duration, timingFunction: timingFunction, completion: completion)
    }
    open func change(opacity to: CGFloat, animated: Bool = true, _ save:Bool = true, removeOnCompletion: Bool = true, duration:Double = 0.2, timingFunction: CAMediaTimingFunctionName = CAMediaTimingFunctionName.easeOut, completion:((Bool)->Void)? = nil) {
        super._change(opacity: to, animated: animated, save, removeOnCompletion: removeOnCompletion, duration: duration, timingFunction: timingFunction, completion: completion)
    }


    
}
