import Cocoa

import Foundation

private func getBits(data: UnsafeRawPointer, length: Int, bitOffset: Int, numBits: Int) -> Int32 {
    let normalizedNumBits = Int(pow(2.0, Double(numBits))) - 1
    let byteOffset = bitOffset / 8
    let normalizedData = data.advanced(by: byteOffset)
    let normalizedBitOffset = bitOffset % 8
    
    var value: Int32 = 0
    if byteOffset + 4 > length {
        let remaining = length - byteOffset
        withUnsafeMutableBytes(of: &value, { (bytes: UnsafeMutableRawBufferPointer) -> Void in
            memcpy(bytes.baseAddress!, normalizedData, remaining)
        })
    } else {
        value = normalizedData.assumingMemoryBound(to: Int32.self).pointee
    }
    return (value >> Int32(normalizedBitOffset)) & Int32(normalizedNumBits)
}

private func setBits(data: UnsafeMutableRawPointer, bitOffset: Int, numBits: Int, value: Int32) {
   // let normalizedNumBits = Int(pow(2.0, Double(numBits))) - 1
    let normalizedData = data.advanced(by: bitOffset / 8)
    let normalizedBitOffset = bitOffset % 8
    
    normalizedData.assumingMemoryBound(to: Int32.self).pointee |= value << Int32(normalizedBitOffset)
}

public final class AudioWaveform: Equatable {
    public let samples: Data
    public let peak: Int32
    
    public init(samples: Data, peak: Int32) {
        self.samples = samples
        self.peak = peak
    }
    
    public convenience init(bitstream: Data, bitsPerSample: Int) {
        let numSamples = Int(Float(bitstream.count * 8) / Float(bitsPerSample))
        var result = Data()
        result.count = numSamples * 2
        
        bitstream.withUnsafeBytes { (bytes: UnsafePointer<Int8>) -> Void in
            //let maxSample = (1 << bitsPerSample) - 1
            
            result.withUnsafeMutableBytes { (samples: UnsafeMutablePointer<Int16>) -> Void in
                let norm = Int64((1 << bitsPerSample) - 1)
                for i in 0 ..< numSamples {
                    samples[i] = Int16(Int64(getBits(data: bytes, length: bitstream.count, bitOffset: i * 5, numBits: 5)) * norm / norm)
                }
            }
        }
        
        self.init(samples: result, peak: 31)
    }
    
    public func makeBitstream() -> Data {
        let numSamples = self.samples.count / 2
        let bitstreamLength = (numSamples * 5) / 8 + (((numSamples * 5) % 8) == 0 ? 0 : 1)
        var result = Data()
        result.count = bitstreamLength + 4

        let maxSample: Int32 = self.peak
        
        self.samples.withUnsafeBytes { (samples: UnsafePointer<Int16>) -> Void in
            result.withUnsafeMutableBytes { (bytes: UnsafeMutablePointer<Int16>) -> Void in
                for i in 0 ..< numSamples {
                    let value: Int32 = min(Int32(31), abs(Int32(samples[i])) * 31 / maxSample)
                    setBits(data: bytes, bitOffset: i * 5, numBits: 5, value: value & Int32(31))
                }
            }
        }

        result.count = bitstreamLength

        return result
    }
    
    public func peaks(count: Int) -> [CGFloat] {
        let sourceCount = self.samples.count / 2
        guard count > 0, sourceCount > 0 else {
            return []
        }
        var result = [CGFloat](repeating: 0, count: count)
        self.samples.withUnsafeBytes { (samples: UnsafePointer<UInt16>) -> Void in
            var maxSample: UInt16 = 0
            for i in 0 ..< sourceCount {
                maxSample = max(maxSample, samples[i])
            }
            let invScale = 1.0 / max(1.0, CGFloat(maxSample))
            for i in 0 ..< count {
                let start = i * sourceCount / count
                let end = min(sourceCount, max(start + 1, (i + 1) * sourceCount / count))
                var peak: UInt16 = 0
                for j in start ..< end {
                    peak = max(peak, samples[j])
                }
                result[i] = CGFloat(peak) * invScale
            }
        }
        return result
    }
    
    public func subwaveform(from start: Double, to end: Double) -> AudioWaveform {
        let lower = max(0.0, min(1.0, start))
        let upper = max(lower, min(1.0, end))
        let numSamples = self.samples.count / 2
        let startIndex = Int(Double(numSamples) * lower) * 2
        let endIndex = Int(Double(numSamples) * upper) * 2
        guard endIndex > startIndex else {
            return AudioWaveform(samples: Data(), peak: self.peak)
        }
        return AudioWaveform(samples: self.samples.subdata(in: startIndex ..< endIndex), peak: self.peak)
    }
    
    public static func ==(lhs: AudioWaveform, rhs: AudioWaveform) -> Bool {
        return lhs.peak == rhs.peak && lhs.samples == rhs.samples
    }
}

import Cocoa
import TGUIKit

fileprivate final class AudioWaveformDrawingSamples {
    struct Prepared {
        let peaks: [UInt16]
        let inverseScale: CGFloat
    }

    private var waveform: AudioWaveform?
    private var prepared: Prepared?

    func reset() {
        waveform = nil
        prepared = nil
    }

    func prepare(_ waveform: AudioWaveform, count: Int) -> Prepared {
        if self.waveform === waveform, let prepared, prepared.peaks.count == count {
            return prepared
        }
        var peaks = [UInt16](repeating: 0, count: count)
        var maximum: UInt16 = 0
        waveform.samples.withUnsafeBytes { (samples: UnsafePointer<UInt16>) -> Void in
            let sourceCount = waveform.samples.count / 2
            for index in 0 ..< sourceCount {
                let sample = samples[index]
                maximum = max(maximum, sample)
                let bucket = index * count / sourceCount
                peaks[bucket] = max(peaks[bucket], sample)
            }
        }
        let prepared = Prepared(peaks: peaks, inverseScale: 1.0 / max(1.0, CGFloat(maximum)))
        self.waveform = waveform
        self.prepared = prepared
        return prepared
    }
}

fileprivate class AudioWaveformContainerView : SimpleLayer {
    private let drawingSamples: AudioWaveformDrawingSamples

    var color:NSColor = .accent {
        didSet {
            if color != oldValue {
                self.setNeedsDisplay()
            }
        }
    }
    var waveform:AudioWaveform? {
        didSet {
            if waveform !== oldValue {
                drawingSamples.reset()
            }
            if waveform != oldValue {
                self.setNeedsDisplay()
            }
        }
    }
    var peakHeight:CGFloat = 12
    var revealProgress: CGFloat = 1.0 {
        didSet {
            if revealProgress != oldValue {
                self.setNeedsDisplay()
            }
        }
    }
    init(frame frameRect: NSRect, drawingSamples: AudioWaveformDrawingSamples) {
        self.drawingSamples = drawingSamples
        super.init()
        self.frame = frameRect
        self.needsDisplayOnBoundsChange = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        self.drawingSamples = AudioWaveformDrawingSamples()
        super.init()
        self.needsDisplayOnBoundsChange = true
    }
    
    override func draw(in ctx: CGContext) {
        
        let sampleWidth:CGFloat = 2
        let halfSampleWidth:CGFloat = 1
        let distance:CGFloat = 2
        let size = frame.size
        
        ctx.setFillColor(color.cgColor)
        
        if let waveform = waveform {

            
            guard size.width.isFinite, size.width >= sampleWidth + distance else {
                return
            }
            let numSamples = Int(floor(size.width / (sampleWidth + distance)))
            let samples = drawingSamples.prepare(waveform, count: numSamples)
            let peakHeight: CGFloat = 12.0
            let invScale = samples.inverseScale

            let commonRevealFraction = listViewAnimationCurveSystem(self.revealProgress)

            for i in 0 ..< numSamples {
                let offset = CGFloat(i) * (sampleWidth + distance)
                let peakSample = samples.peaks[i]

                var sampleHeight = CGFloat(peakSample) * peakHeight * invScale
                if abs(sampleHeight) > peakHeight {
                    sampleHeight = peakHeight
                }

                let startFraction = CGFloat(i) / CGFloat(numSamples)
                if startFraction < commonRevealFraction {
                    sampleHeight *= max(0.0, min(1.0, (commonRevealFraction - startFraction) / (1.0 - startFraction)))
                } else {
                    sampleHeight = 0.0
                }

                let adjustedSampleHeight = sampleHeight - sampleWidth * 1.5
                if adjustedSampleHeight.isLessThanOrEqualTo(sampleWidth) {
                    ctx.fillEllipse(in: CGRect(x: offset, y: size.height - sampleWidth, width: sampleWidth, height: sampleWidth))
                } else {
                    let adjustedRect = CGRect(x: offset, y: size.height - adjustedSampleHeight, width: sampleWidth, height: adjustedSampleHeight - halfSampleWidth)
                    ctx.fillEllipse(in: CGRect(x: adjustedRect.minX, y: adjustedRect.minY - halfSampleWidth, width: sampleWidth, height: sampleWidth))
                    ctx.fillEllipse(in: CGRect(x: adjustedRect.minX, y: adjustedRect.maxY - halfSampleWidth, width: sampleWidth, height: sampleWidth))
                    ctx.fill(adjustedRect)
                }
            }
        } else {
            
            ctx.fill(NSMakeRect(halfSampleWidth, size.height - sampleWidth, size.width - sampleWidth, sampleWidth))
            ctx.fillEllipse(in: NSMakeRect(0.0, size.height - sampleWidth, sampleWidth, sampleWidth))
            ctx.fillEllipse(in: NSMakeRect(size.width - sampleWidth, size.height - sampleWidth, sampleWidth, sampleWidth))
            
  
        }
    }
    
}

public class AudioWaveformView: View {
    private let foregroundView:AudioWaveformContainerView
    private let backgroundView:AudioWaveformContainerView
    public let foregroundClipingView:View
    
    var peakHeight:CGFloat = 12 {
        didSet {
            foregroundView.peakHeight = peakHeight
            backgroundView.peakHeight = peakHeight
        }
    }
    
    public var waveform:AudioWaveform? {
        didSet {
            foregroundView.waveform = waveform
            backgroundView.waveform = waveform
        }
    }
    
    public required init(frame frameRect: NSRect) {
        let drawingSamples = AudioWaveformDrawingSamples()
        foregroundView = AudioWaveformContainerView(frame: NSMakeRect(0,0,frameRect.width,frameRect.height), drawingSamples: drawingSamples)
        backgroundView = AudioWaveformContainerView(frame: NSMakeRect(0,0,frameRect.width,frameRect.height), drawingSamples: drawingSamples)
        foregroundClipingView = View(frame: NSMakeRect(0,0,frameRect.width,frameRect.height))
        super.init(frame: frameRect)
        
        self.layer?.addSublayer(backgroundView)
        
        foregroundClipingView.layer?.addSublayer(foregroundView)
        addSubview(foregroundClipingView)
    }
    
    public override func mouseDragged(with event: NSEvent) {
        super.mouseDragged(with: event)
    }
    
    public override func setFrameSize(_ newSize: NSSize) {
        super.setFrameSize(newSize)
    }
    
    public override func layout() {
        super.layout()
        foregroundView.frame = self.bounds
        backgroundView.frame = self.bounds

    }
    
    public func set(foregroundColor:NSColor, backgroundColor:NSColor) {
        self.foregroundView.color = foregroundColor
        self.backgroundView.color = backgroundColor
    }

    private var revealAnimator: DisplayLinkAnimator?

    public func animateIn() {
        guard self.revealAnimator == nil else {
            return
        }
        let delay: CGFloat = 0.08
        let duration: CGFloat = 0.8
        self.updateRevealProgress(0.0)
        self.revealAnimator = DisplayLinkAnimator(duration: Double(delay + duration), from: 0.0, to: delay + duration, timingFunction: CAMediaTimingFunction(name: .linear), update: { [weak self] elapsed in
            self?.updateRevealProgress(max(0.0, min(1.0, (elapsed - delay) / duration)))
        }, completion: { [weak self] in
            self?.updateRevealProgress(1.0)
            self?.revealAnimator = nil
        })
    }

    private func updateRevealProgress(_ progress: CGFloat) {
        self.foregroundView.revealProgress = progress
        self.backgroundView.revealProgress = progress
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}




extension AudioWaveformView {
    func testProgress(_ progress: CGFloat) {
        updateRevealProgress(progress)
    }

    func testDraw(_ context: CGContext, foreground: Bool) {
        (foreground ? foregroundView : backgroundView).draw(in: context)
    }

    var testLayers: [CALayer] { [foregroundView, backgroundView] }
}

extension AudioWaveformDrawingSamples {
    var testSnapshot: ([UInt16], CGFloat)? {
        prepared.map { ($0.peaks, $0.inverseScale) }
    }
}
extension AudioWaveformContainerView {
    var testPreparation: AudioWaveformDrawingSamples { drawingSamples }
}
extension AudioWaveformView {
    var testSnapshot: ([UInt16], CGFloat)? { foregroundView.testPreparation.testSnapshot }
    var testSharedPreparation: Bool { foregroundView.testPreparation === backgroundView.testPreparation }
}
