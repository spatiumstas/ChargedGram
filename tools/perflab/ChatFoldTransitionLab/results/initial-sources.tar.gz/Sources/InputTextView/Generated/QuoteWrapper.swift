import Cocoa
import TGUIKit

private let quoteIcon: CGImage = {
    return TelegramThemeHooks.shared.image(.iconQuote).precomposed(flipVertical: false)
}()
private final class FoldingQuoteMaskCache {
    static let shared = FoldingQuoteMaskCache()

    private struct Key: Hashable {
        let width: CGFloat
        let height: CGFloat
        let y: CGFloat
        let scale: CGFloat
    }

    private let lock = NSLock()
    private let maximumCount: Int
    private let maximumBytes: Int
    private var settings: DeviceGraphicsContextSettings?
    private var images: [Key: CGImage] = [:]
    private var order: [Key] = []
    private var retainedBytes = 0

    init(maximumCount: Int = 32, maximumBytes: Int = 2 * 1024 * 1024) {
        self.maximumCount = maximumCount
        self.maximumBytes = maximumBytes
    }

    func image(size: NSSize, y: CGFloat, scale: CGFloat) -> CGImage? {
        let key = Key(width: size.width, height: size.height, y: y, scale: scale)
        let settings = DeviceGraphicsContextSettings.shared
        lock.lock()
        if self.settings != settings {
            images.removeAll(keepingCapacity: true)
            order.removeAll(keepingCapacity: true)
            retainedBytes = 0
            self.settings = settings
        }
        if let image = images[key] {
            lock.unlock()
            return image
        }
        lock.unlock()

        guard let image = renderFoldingQuoteMask(size: size, y: y, scale: scale) else { return nil }
        let cost = image.bytesPerRow * image.height
        guard maximumCount > 0, cost <= maximumBytes else { return image }

        lock.lock()
        defer { lock.unlock() }
        guard self.settings == settings, DeviceGraphicsContextSettings.shared == settings else { return image }
        if let existing = images[key] { return existing }
        while !order.isEmpty && (order.count >= maximumCount || retainedBytes > maximumBytes - cost) {
            let removed = order.removeFirst()
            if let previous = images.removeValue(forKey: removed) {
                retainedBytes -= previous.bytesPerRow * previous.height
            }
        }
        images[key] = image
        order.append(key)
        retainedBytes += cost
        return image
    }
}
private func renderFoldingQuoteMask(size: NSSize, y: CGFloat, scale: CGFloat) -> CGImage? {
    return generateImage(size, scale: scale, rotatedContext: { size, context in
        context.clear(CGRect(origin: .zero, size: size))
        
        context.setFillColor(NSColor.white.cgColor)
        context.fill(CGRect(origin: .zero, size: size))
        
        var locations: [CGFloat] = [0.0, 0.7, 1.0]
        let colors: [CGColor] = [NSColor.white.cgColor, NSColor.white.withAlphaComponent(0.0).cgColor, NSColor.white.withAlphaComponent(0.0).cgColor]
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let gradient = CGGradient(colorsSpace: colorSpace, colors: colors as CFArray, locations: &locations)!
        
        context.setBlendMode(.copy)
        context.clip(to: CGRect(origin: CGPoint(x: 0, y: y), size: CGSize(width: size.width, height: size.height)))
        context.drawLinearGradient(gradient, start: CGPoint(x: size.width - size.width / 4, y: 0.0), end: CGPoint(x: size.width, y: 0.0), options: CGGradientDrawingOptions())
    })
}
private func generateMaskImage(size: NSSize, y: CGFloat) -> CGImage? {
    return FoldingQuoteMaskCache.shared.image(size: size, y: y, scale: System.backingScale)
}

extension FoldingTextLayout {
    public struct ViewLayout {
        public let text: TextViewLayout
        public let arrowDown: CGImage?
        public let arrowUp: CGImage?
        public let mask: CGImage?
        public let isRevealed: Bool
        public let collapsable: Bool
        public let size: NSSize
        func updated(width: CGFloat, revealed: Bool, collapsable: Bool, isBigEmoji: Bool) -> ViewLayout {
            text.measure(width: width, isBigEmoji: isBigEmoji)
            
            let isRevealed = revealed || text.blockQuotes.isEmpty || text.lines.count <= 3 || !collapsable
            
            let size: NSSize
            if isRevealed {
                size = text.layoutSize
            } else {
                size = NSMakeSize(text.layoutSize.width, text.lines[1].frame.maxY + 8)
            }
            
            let arrowDown: CGImage?
            let arrowUp: CGImage?
            
            if text.hasBlockQuotes && canReveal {
                let mainColor = text.blockQuotes[0].colors.main
                
                let generateArrow:(NSSize, CGContext)->Void = { size, context in
                    context.clear(CGRect(origin: CGPoint(), size: size))
                    context.setStrokeColor(mainColor.cgColor)
                    context.setLineWidth(1.5)
                    context.setLineCap(.round)
                    context.setLineJoin(.round)
                    context.beginPath()
                    context.move(to: CGPoint(x: 1.0, y: 1.0))
                    context.addLine(to: CGPoint(x: size.width / 2.0, y: size.height - 2.0))
                    context.addLine(to: CGPoint(x: size.width - 1.0, y: 1.0))
                    context.strokePath()
                }
                
                arrowDown = self.arrowDown ?? generateImage(CGSize(width: 10, height: 7), rotatedContext: generateArrow)
                arrowUp = self.arrowUp ?? generateImage(CGSize(width: 10, height: 7), contextGenerator: generateArrow)
            } else {
                arrowDown = nil
                arrowUp = nil
            }
            
            
            if text.hasBlockQuotes && !isRevealed {
                return .init(text: text, arrowDown: arrowDown, arrowUp: arrowUp, mask: generateMaskImage(size: NSMakeSize(size.width, size.height - 5), y: text.lines[0].frame.maxY + 2), isRevealed: isRevealed, collapsable: collapsable, size: size)
            } else {
                return .init(text: text, arrowDown: arrowDown, arrowUp: arrowUp, mask: nil, isRevealed: isRevealed, collapsable: collapsable, size: size)
            }
        }
        
        public var layoutSize: NSSize {
            return self.text.layoutSize
        }
        
        public var canReveal: Bool {
            return collapsable && !self.text.blockQuotes.isEmpty && self.text.lines.count > 3
        }
        
        func makeImageBlock(backgroundColor: NSColor) {
            self.text.maskBlockImage = self.text.generateBlock(backgroundColor: backgroundColor)
        }
    }
}

private protocol FoldingBlockInteractionState: AnyObject {
    var ignoreNextClick: Bool { get set }
}
private final class WrapperView : View {

    class BlockLayer: SimpleLayer {
        var blockQuotes: [TextViewBlockQuote] = [] {
            didSet {
                setNeedsDisplay()
            }
        }
        override func draw(in ctx: CGContext) {
            for blockQuote in blockQuotes {
                let radius: CGFloat = 3.0
                let lineWidth: CGFloat = 3.0


                let blockFrame = blockQuote.frame
                let blockColor = blockQuote.isCode ? blockQuote.colors.tertiary ?? blockQuote.colors.main : blockQuote.colors.main
                let tintColor = blockQuote.colors.main
                let secondaryTintColor = blockQuote.colors.secondary
                let tertiaryTintColor = blockQuote.colors.tertiary


                var bg = blockColor
                if blockQuote.isCode {
                    bg = bg.darker(amount: 0.5).withAlphaComponent(0.5)
                } else {
                    bg = bg.withAlphaComponent(0.1)
                }
                ctx.setFillColor(bg.cgColor)
                ctx.addPath(CGPath(roundedRect: blockFrame, cornerWidth: radius, cornerHeight: radius, transform: nil))
                ctx.fillPath()

                ctx.setFillColor(tintColor.cgColor)

                if !blockQuote.isCode {
                    let iconSize = quoteIcon.backingSize
                    let quoteRect = CGRect(origin: CGPoint(x: blockFrame.maxX - 4.0 - iconSize.width, y: blockFrame.minY + 4.0), size: iconSize)
                    ctx.saveGState()
                    ctx.translateBy(x: quoteRect.midX, y: quoteRect.midY)
                    ctx.scaleBy(x: 1.0, y: -1.0)
                    ctx.translateBy(x: -quoteRect.midX, y: -quoteRect.midY)
                    ctx.clip(to: quoteRect, mask: quoteIcon)
                    ctx.fill(quoteRect)
                    ctx.restoreGState()
                    ctx.resetClip()
                }


                drawBlockQuoteLine(ctx: ctx, blockFrame: blockFrame, radius: radius, lineWidth: lineWidth, tintColor: tintColor, secondaryTintColor: secondaryTintColor, tertiaryTintColor: tertiaryTintColor)

                if let header = blockQuote.header {
                    let headerHeight = blockQuote.headerInset + 2
                    ctx.setFillColor(blockQuote.colors.main.withAlphaComponent(0.2).cgColor)
                    let rect = NSMakeRect(blockFrame.minX, blockFrame.minY, blockFrame.width, headerHeight)
                    ctx.drawRoundedRect(rect: rect, topLeftRadius: radius, topRightRadius: radius)
                    header.1.draw(CGRect(x: blockFrame.minX + 8, y: blockFrame.minY + (headerHeight - header.0.size.height) / 2 - 1, width: header.0.size.width, height: header.0.size.height), in: ctx, backingScaleFactor: System.backingScale, backgroundColor: .clear)
                    let image = TelegramThemeHooks.shared.image(.iconCopyCode).precomposed(blockQuote.colors.main, flipVertical: true)
                    ctx.draw(image, in: CGRect(origin: NSMakePoint(blockFrame.width - image.backingSize.width - 3, blockFrame.minY + (headerHeight - image.backingSize.height) / 2), size: image.backingSize))
                }
            }
        }
    }

    let textView = TextView()
    private let mask: SimpleShapeLayer = SimpleShapeLayer()
    private var textMask: SimpleLayer?
    private var blockLayer: BlockLayer?
    private var arrow: SimpleLayer?


    var currentLayout: FoldingTextLayout.ViewLayout?

    var isLite: Bool = false

    private let inlineStickers = FoldingInlineStickers()


    required init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        addSubview(textView)
        self.layer?.mask = mask
    }

    func update(_ layout: FoldingTextLayout.ViewLayout, isRevealed: Bool, context: any AccountContextProtocol, transition: ContainedViewLayoutTransition) {

        let previousLayout = self.currentLayout

        self.currentLayout = layout

        let isRevealed = layout.isRevealed

        self.isLite = context.isLite(.emoji)

        textView.canDrawBlocks = !layout.canReveal

        self.textView.update(layout.text)

        let size = layout.size



        let path = CGMutablePath()

        if layout.canReveal {
            path.addRoundedRect(in: size.bounds, cornerWidth: min(size.width / 2, 4), cornerHeight: min(size.height / 2, 4))
        } else {
            path.addRoundedRect(in: size.bounds, cornerWidth: 0, cornerHeight: 0)
        }


        let animation = mask.makeAnimation(from: self.mask.path ?? CGMutablePath(), to: path, keyPath: "path", timingFunction: transition.timingFunction, duration: transition.duration)
        if transition.isAnimated {
            mask.add(animation, forKey: "path")
        }
        mask.path = path

        self.layer?.masksToBounds = layout.text.hasBlockQuotes
        self.layer?.mask = layout.text.hasBlockQuotes ? mask : nil


        if layout.canReveal {
            let current: BlockLayer
            if let layer = self.blockLayer {
                current = layer
            } else {
                current = BlockLayer(frame: size.bounds)
                self.layer?.addSublayer(current)
                self.blockLayer = current
            }
            current.blockQuotes = layout.text.blockQuotes
            transition.updateFrame(layer: current, frame: layout.layoutSize.bounds)
            current.mask = mask
        } else {
            if let layer = self.blockLayer {
                performSublayerRemoval(layer, animated: transition.isAnimated)
                self.blockLayer = nil
            }
        }

        if !isRevealed {
            let current: SimpleLayer
            if let layer = self.textMask {
                current = layer
            } else {
                current = .init(frame: size.bounds)
                self.textMask = current
            }
            current.contents = layout.mask
            current.contentsGravity = .bottom
            current.frame = size.bounds
            if transition.isAnimated {
                delay(transition.duration, closure: { [weak self] in
                    self?.textView.set(mask: self?.textMask)
                })
            } else {
                self.textView.set(mask: current)
            }
        } else {
            self.textMask = nil
            self.textView.set(mask: nil)
        }

        if layout.canReveal {
            let current: SimpleLayer
            if let layer = self.arrow {
                current = layer
            } else {
                let s = NSMakeSize(10, 7)
                current = SimpleLayer(frame: NSMakeRect(size.width - s.width - 5, size.height - s.height - 6, s.width, s.height))
                self.arrow = current
                self.layer?.addSublayer(current)
            }
            current.anchorPoint = NSMakePoint(0, 0)
            current.contents = layout.isRevealed ? layout.arrowUp : layout.arrowDown

            if previousLayout?.isRevealed != layout.isRevealed, transition.isAnimated {
                current.animateContents()
            }
        } else if let arrow = self.arrow {
            performSublayerRemoval(arrow, animated: transition.isAnimated)
            self.arrow = nil
        }

        self.textView.setIsShimmering(true, animated: transition.isAnimated)

        self.updateInlineStickers(context: context, textLayout: layout.text)
        self.updateAnimatableContent()

        transition.updateFrame(view: self, frame: CGRect(origin: self.frame.origin, size: size))
        self.updateLayout(size: size, transition: transition)
    }

    func updateLayout(size: NSSize, transition: ContainedViewLayoutTransition) {
        if let arrow = arrow {
            transition.updateFrame(layer: arrow, frame: NSMakeRect(size.width - arrow.frame.width - 5, size.height - arrow.frame.height - 6, arrow.frame.width, arrow.frame.height))
        }
    }


    override func layout() {
        super.layout()
        self.updateLayout(size: self.frame.size, transition: .immediate)
    }

    required public init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }



    func updateInlineStickers(context: any AccountContextProtocol, textLayout: TextViewLayout) {
        inlineStickers.update(textView: textView, context: context, textLayout: textLayout)
    }


    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        self.updateListeners()
        self.updateAnimatableContent()
    }
    override func viewDidMoveToSuperview() {
        super.viewDidMoveToSuperview()
        self.updateListeners()
        self.updateAnimatableContent()
    }

    @objc func updateAnimatableContent() -> Void {
        inlineStickers.updateAnimatableContent(window: window, isLite: isLite)
    }
    private let animatableContentObserver = AnimatableContentObserver()

    private func updateListeners() {
        animatableContentObserver.update(for: self, target: self, selector: #selector(updateAnimatableContent), options: [.contentBounds, .documentFrame, .ownFrame])
    }

}

private final class CandidateWrapperView : View, FoldingBlockInteractionState {
    var ignoreNextClick = false
    
    
    let textView = TextView()
    private let mask: SimpleShapeLayer = SimpleShapeLayer()
    private var textMask: SimpleLayer?
    private var blockLayer: FoldingTextQuoteLayer?
    private var arrow: SimpleLayer?
    
    
    var currentLayout: FoldingTextLayout.ViewLayout?
    
    var isLite: Bool = false
    
    fileprivate let inlineStickers = FoldingInlineStickers()

    
    var hasActiveContentAnimation: Bool {
        return mask.animationKeys()?.isEmpty == false || arrow?.animationKeys()?.isEmpty == false
    }

    required init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        addSubview(textView)
        self.layer?.mask = mask
    }
    
    func update(_ layout: FoldingTextLayout.ViewLayout, isRevealed: Bool, context: any AccountContextProtocol, transition: ContainedViewLayoutTransition) {
        
        let previousLayout = self.currentLayout
        
        self.currentLayout = layout
        
        let isRevealed = layout.isRevealed
        
        self.isLite = context.isLite(.emoji)
        
        textView.canDrawBlocks = !layout.canReveal

        self.textView.update(layout.text)
        
        let size = layout.size
 
        
        
        let path = CGMutablePath()
        
        if layout.canReveal {
            path.addRoundedRect(in: size.bounds, cornerWidth: min(size.width / 2, 4), cornerHeight: min(size.height / 2, 4))
        } else {
            path.addRoundedRect(in: size.bounds, cornerWidth: 0, cornerHeight: 0)
        }
        
        
        if transition.isAnimated {
            let animation = mask.makeAnimation(from: self.mask.path ?? CGMutablePath(), to: path, keyPath: "path", timingFunction: transition.timingFunction, duration: transition.duration)
            mask.add(animation, forKey: "path")
        }
        mask.path = path
        
        self.layer?.masksToBounds = layout.text.hasBlockQuotes
        self.layer?.mask = layout.text.hasBlockQuotes ? mask : nil


        if layout.canReveal {
            let current: FoldingTextQuoteLayer
            if let layer = self.blockLayer {
                current = layer
            } else {
                current = FoldingTextQuoteLayer(frame: size.bounds)
                self.layer?.addSublayer(current)
                self.blockLayer = current
            }
            current.blockQuotes = layout.text.blockQuotes
            transition.updateFrame(layer: current, frame: layout.layoutSize.bounds)
            current.mask = mask
        } else {
            if let layer = self.blockLayer {
                performSublayerRemoval(layer, animated: transition.isAnimated)
                self.blockLayer = nil
            }
        }
        
        if !isRevealed {
            let current: SimpleLayer
            if let layer = self.textMask {
                current = layer
            } else {
                current = .init(frame: size.bounds)
                self.textMask = current
            }
            current.contents = layout.mask
            current.contentsGravity = .bottom
            current.frame = size.bounds
            if transition.isAnimated {
                delay(transition.duration, closure: { [weak self] in
                    self?.textView.set(mask: self?.textMask)
                })
            } else {
                self.textView.set(mask: current)
            }
        } else {
            self.textMask = nil
            self.textView.set(mask: nil)
        }
        
        if layout.canReveal {
            let current: SimpleLayer
            if let layer = self.arrow {
                current = layer
            } else {
                let s = NSMakeSize(10, 7)
                current = SimpleLayer(frame: NSMakeRect(size.width - s.width - 5, size.height - s.height - 6, s.width, s.height))
                self.arrow = current
                self.layer?.addSublayer(current)
            }
            current.anchorPoint = NSMakePoint(0, 0)
            current.contents = layout.isRevealed ? layout.arrowUp : layout.arrowDown
            
            if previousLayout?.isRevealed != layout.isRevealed, transition.isAnimated {
                current.animateContents()
            }
        } else if let arrow = self.arrow {
            performSublayerRemoval(arrow, animated: transition.isAnimated)
            self.arrow = nil
        }
        
        self.textView.setIsShimmering(true, animated: transition.isAnimated)
        
        self.updateInlineStickers(context: context, textLayout: layout.text)
        self.updateListeners()
        self.updateAnimatableContent()
        
        transition.updateFrame(view: self, frame: CGRect(origin: self.frame.origin, size: size))
        self.updateLayout(size: size, transition: transition)
    }
    
    func updateLayout(size: NSSize, transition: ContainedViewLayoutTransition) {
        if let arrow = arrow {
            transition.updateFrame(layer: arrow, frame: NSMakeRect(size.width - arrow.frame.width - 5, size.height - arrow.frame.height - 6, arrow.frame.width, arrow.frame.height))
        }
    }
    
    
    override func layout() {
        super.layout()
        self.updateLayout(size: self.frame.size, transition: .immediate)
    }

    required public init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    func updateInlineStickers(context: any AccountContextProtocol, textLayout: TextViewLayout) {
        inlineStickers.update(textView: textView, context: context, textLayout: textLayout)
    }
    
    
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        self.updateListeners()
        self.updateAnimatableContent()
    }
    override func viewDidMoveToSuperview() {
        super.viewDidMoveToSuperview()
        self.updateListeners()
        self.updateAnimatableContent()
    }
    
    @objc func updateAnimatableContent() -> Void {
        inlineStickers.updateAnimatableContent(window: window, isLite: isLite)
    }
    private var animatableContentObserver: AnimatableContentObserver?

    private func updateListeners() {
        guard !inlineStickers.isEmpty else {
            animatableContentObserver = nil
            return
        }
        if animatableContentObserver == nil { animatableContentObserver = AnimatableContentObserver() }
        animatableContentObserver?.update(for: self, target: self, selector: #selector(updateAnimatableContent), options: [.contentBounds, .documentFrame, .ownFrame])
    }

}

public func makeReferenceFoldingWrapper(_ layout: FoldingTextLayout.ViewLayout) -> View {
    let view = WrapperView(frame: CGRect(origin: .zero, size: layout.size))
    view.update(layout, isRevealed: layout.isRevealed, context: ReferenceContext(), transition: .immediate)
    return view
}
public func updateReferenceFoldingWrapper(_ view: View, layout: FoldingTextLayout.ViewLayout) {
    (view as! WrapperView).update(layout, isRevealed: layout.isRevealed, context: ReferenceContext(), transition: .immediate)
}
public func isReferenceFoldingWrapper(_ view: View) -> Bool { view is WrapperView }
public func makeCandidateFoldingWrapper(_ layout: FoldingTextLayout.ViewLayout) -> View {
    let view = CandidateWrapperView(frame: CGRect(origin: .zero, size: layout.size))
    view.update(layout, isRevealed: layout.isRevealed, context: ReferenceContext(), transition: .immediate)
    return view
}

public func updateCandidateFoldingWrapper(_ view: View, layout: FoldingTextLayout.ViewLayout, transition: ContainedViewLayoutTransition) {
    (view as! CandidateWrapperView).update(layout, isRevealed: layout.isRevealed, context: ReferenceContext(), transition: transition)
}
